﻿
namespace BetterLimited
{
    partial class SignupForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblStaffID = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblConfirmPassword = new System.Windows.Forms.Label();
            this.txtStaffID = new System.Windows.Forms.TextBox();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtConfirmPassword = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSignup = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblEmailWarning = new System.Windows.Forms.Label();
            this.lblCPasswordWarning = new System.Windows.Forms.Label();
            this.lblPasswordWarning = new System.Windows.Forms.Label();
            this.lblUsernameWarning = new System.Windows.Forms.Label();
            this.lblStaffIDWarning = new System.Windows.Forms.Label();
            this.picShowPassword = new System.Windows.Forms.PictureBox();
            this.picShowCPassword = new System.Windows.Forms.PictureBox();
            this.lblLowercase = new System.Windows.Forms.Label();
            this.lblNumber = new System.Windows.Forms.Label();
            this.lblUppercase = new System.Windows.Forms.Label();
            this.lblSymbols = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.picShowPassword)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picShowCPassword)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 30F);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(16, 90);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1035, 180);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sign Up";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblStaffID
            // 
            this.lblStaffID.AutoSize = true;
            this.lblStaffID.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.lblStaffID.ForeColor = System.Drawing.Color.Black;
            this.lblStaffID.Location = new System.Drawing.Point(73, 273);
            this.lblStaffID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStaffID.Name = "lblStaffID";
            this.lblStaffID.Size = new System.Drawing.Size(83, 27);
            this.lblStaffID.TabIndex = 4;
            this.lblStaffID.Text = "Staff ID";
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.lblUsername.ForeColor = System.Drawing.Color.Black;
            this.lblUsername.Location = new System.Drawing.Point(73, 333);
            this.lblUsername.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(108, 27);
            this.lblUsername.TabIndex = 5;
            this.lblUsername.Text = "Username";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.lblPassword.ForeColor = System.Drawing.Color.Black;
            this.lblPassword.Location = new System.Drawing.Point(73, 403);
            this.lblPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(103, 27);
            this.lblPassword.TabIndex = 6;
            this.lblPassword.Text = "Password";
            // 
            // lblConfirmPassword
            // 
            this.lblConfirmPassword.AutoSize = true;
            this.lblConfirmPassword.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.lblConfirmPassword.ForeColor = System.Drawing.Color.Black;
            this.lblConfirmPassword.Location = new System.Drawing.Point(73, 473);
            this.lblConfirmPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblConfirmPassword.Name = "lblConfirmPassword";
            this.lblConfirmPassword.Size = new System.Drawing.Size(186, 27);
            this.lblConfirmPassword.TabIndex = 7;
            this.lblConfirmPassword.Text = "Confirm Password";
            // 
            // txtStaffID
            // 
            this.txtStaffID.Location = new System.Drawing.Point(281, 269);
            this.txtStaffID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtStaffID.MaxLength = 5;
            this.txtStaffID.Name = "txtStaffID";
            this.txtStaffID.Size = new System.Drawing.Size(295, 25);
            this.txtStaffID.TabIndex = 8;
            this.txtStaffID.Validating += new System.ComponentModel.CancelEventHandler(this.txtStaffID_Validating);
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(281, 339);
            this.txtUsername.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtUsername.MaxLength = 20;
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(295, 25);
            this.txtUsername.TabIndex = 9;
            this.txtUsername.Validating += new System.ComponentModel.CancelEventHandler(this.txtUsername_Validating);
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(281, 409);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPassword.MaxLength = 20;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(295, 25);
            this.txtPassword.TabIndex = 10;
            this.txtPassword.TextChanged += new System.EventHandler(this.txtPassword_TextChanged);
            this.txtPassword.Validating += new System.ComponentModel.CancelEventHandler(this.txtPassword_Validating);
            // 
            // txtConfirmPassword
            // 
            this.txtConfirmPassword.Location = new System.Drawing.Point(281, 479);
            this.txtConfirmPassword.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtConfirmPassword.MaxLength = 20;
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.Size = new System.Drawing.Size(295, 25);
            this.txtConfirmPassword.TabIndex = 11;
            this.txtConfirmPassword.TextChanged += new System.EventHandler(this.txtConfirmPassword_TextChanged);
            this.txtConfirmPassword.Validating += new System.ComponentModel.CancelEventHandler(this.txtConfirmPassword_Validating);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(281, 549);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtEmail.MaxLength = 50;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(295, 25);
            this.txtEmail.TabIndex = 13;
            this.txtEmail.Validating += new System.ComponentModel.CancelEventHandler(this.txtEmail_Validating);
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.lblEmail.ForeColor = System.Drawing.Color.Black;
            this.lblEmail.Location = new System.Drawing.Point(73, 543);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(63, 27);
            this.lblEmail.TabIndex = 12;
            this.lblEmail.Text = "Email";
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F);
            this.btnClear.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnClear.Location = new System.Drawing.Point(760, 580);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(125, 40);
            this.btnClear.TabIndex = 15;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSignup
            // 
            this.btnSignup.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F);
            this.btnSignup.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnSignup.Location = new System.Drawing.Point(775, 494);
            this.btnSignup.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSignup.Name = "btnSignup";
            this.btnSignup.Size = new System.Drawing.Size(223, 56);
            this.btnSignup.TabIndex = 14;
            this.btnSignup.Text = "Sign Up";
            this.btnSignup.UseVisualStyleBackColor = true;
            this.btnSignup.Click += new System.EventHandler(this.btnSignup_Click);
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F);
            this.btnBack.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnBack.Location = new System.Drawing.Point(893, 580);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(125, 40);
            this.btnBack.TabIndex = 16;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblEmailWarning
            // 
            this.lblEmailWarning.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailWarning.ForeColor = System.Drawing.Color.Red;
            this.lblEmailWarning.Location = new System.Drawing.Point(275, 580);
            this.lblEmailWarning.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmailWarning.Name = "lblEmailWarning";
            this.lblEmailWarning.Size = new System.Drawing.Size(435, 56);
            this.lblEmailWarning.TabIndex = 19;
            // 
            // lblCPasswordWarning
            // 
            this.lblCPasswordWarning.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCPasswordWarning.ForeColor = System.Drawing.Color.Red;
            this.lblCPasswordWarning.Location = new System.Drawing.Point(275, 510);
            this.lblCPasswordWarning.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCPasswordWarning.Name = "lblCPasswordWarning";
            this.lblCPasswordWarning.Size = new System.Drawing.Size(435, 29);
            this.lblCPasswordWarning.TabIndex = 20;
            // 
            // lblPasswordWarning
            // 
            this.lblPasswordWarning.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPasswordWarning.ForeColor = System.Drawing.Color.Red;
            this.lblPasswordWarning.Location = new System.Drawing.Point(275, 440);
            this.lblPasswordWarning.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPasswordWarning.Name = "lblPasswordWarning";
            this.lblPasswordWarning.Size = new System.Drawing.Size(435, 29);
            this.lblPasswordWarning.TabIndex = 21;
            // 
            // lblUsernameWarning
            // 
            this.lblUsernameWarning.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsernameWarning.ForeColor = System.Drawing.Color.Red;
            this.lblUsernameWarning.Location = new System.Drawing.Point(275, 370);
            this.lblUsernameWarning.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUsernameWarning.Name = "lblUsernameWarning";
            this.lblUsernameWarning.Size = new System.Drawing.Size(455, 29);
            this.lblUsernameWarning.TabIndex = 22;
            // 
            // lblStaffIDWarning
            // 
            this.lblStaffIDWarning.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStaffIDWarning.ForeColor = System.Drawing.Color.Red;
            this.lblStaffIDWarning.Location = new System.Drawing.Point(275, 300);
            this.lblStaffIDWarning.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStaffIDWarning.Name = "lblStaffIDWarning";
            this.lblStaffIDWarning.Size = new System.Drawing.Size(435, 29);
            this.lblStaffIDWarning.TabIndex = 23;
            // 
            // picShowPassword
            // 
            this.picShowPassword.Image = global::BetterLimited.Properties.Resources.show;
            this.picShowPassword.Location = new System.Drawing.Point(599, 401);
            this.picShowPassword.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picShowPassword.Name = "picShowPassword";
            this.picShowPassword.Size = new System.Drawing.Size(40, 38);
            this.picShowPassword.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picShowPassword.TabIndex = 24;
            this.picShowPassword.TabStop = false;
            this.picShowPassword.Click += new System.EventHandler(this.picShowPassword_Click);
            // 
            // picShowCPassword
            // 
            this.picShowCPassword.Image = global::BetterLimited.Properties.Resources.show;
            this.picShowCPassword.Location = new System.Drawing.Point(599, 471);
            this.picShowCPassword.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picShowCPassword.Name = "picShowCPassword";
            this.picShowCPassword.Size = new System.Drawing.Size(40, 38);
            this.picShowCPassword.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picShowCPassword.TabIndex = 25;
            this.picShowCPassword.TabStop = false;
            this.picShowCPassword.Click += new System.EventHandler(this.picShowCPassword_Click);
            // 
            // lblLowercase
            // 
            this.lblLowercase.BackColor = System.Drawing.Color.LightGray;
            this.lblLowercase.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F);
            this.lblLowercase.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblLowercase.Location = new System.Drawing.Point(699, 386);
            this.lblLowercase.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLowercase.Name = "lblLowercase";
            this.lblLowercase.Size = new System.Drawing.Size(97, 35);
            this.lblLowercase.TabIndex = 26;
            this.lblLowercase.Text = "Lowercase";
            this.lblLowercase.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNumber
            // 
            this.lblNumber.BackColor = System.Drawing.Color.LightGray;
            this.lblNumber.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F);
            this.lblNumber.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblNumber.Location = new System.Drawing.Point(699, 425);
            this.lblNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumber.Name = "lblNumber";
            this.lblNumber.Size = new System.Drawing.Size(97, 35);
            this.lblNumber.TabIndex = 27;
            this.lblNumber.Text = "Number";
            this.lblNumber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblUppercase
            // 
            this.lblUppercase.BackColor = System.Drawing.Color.LightGray;
            this.lblUppercase.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F);
            this.lblUppercase.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblUppercase.Location = new System.Drawing.Point(804, 385);
            this.lblUppercase.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUppercase.Name = "lblUppercase";
            this.lblUppercase.Size = new System.Drawing.Size(95, 36);
            this.lblUppercase.TabIndex = 28;
            this.lblUppercase.Text = "Uppercase";
            this.lblUppercase.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSymbols
            // 
            this.lblSymbols.BackColor = System.Drawing.Color.LightGray;
            this.lblSymbols.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F);
            this.lblSymbols.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblSymbols.Location = new System.Drawing.Point(804, 425);
            this.lblSymbols.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSymbols.Name = "lblSymbols";
            this.lblSymbols.Size = new System.Drawing.Size(95, 35);
            this.lblSymbols.TabIndex = 29;
            this.lblSymbols.Text = "Symbols";
            this.lblSymbols.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::BetterLimited.Properties.Resources.Group__1_;
            this.pictureBox1.Location = new System.Drawing.Point(317, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(385, 54);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1067, 100);
            this.panel1.TabIndex = 30;
            // 
            // SignupForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 648);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblSymbols);
            this.Controls.Add(this.lblUppercase);
            this.Controls.Add(this.lblNumber);
            this.Controls.Add(this.lblLowercase);
            this.Controls.Add(this.picShowCPassword);
            this.Controls.Add(this.picShowPassword);
            this.Controls.Add(this.lblStaffIDWarning);
            this.Controls.Add(this.lblUsernameWarning);
            this.Controls.Add(this.lblPasswordWarning);
            this.Controls.Add(this.lblCPasswordWarning);
            this.Controls.Add(this.lblEmailWarning);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnSignup);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtConfirmPassword);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.txtStaffID);
            this.Controls.Add(this.lblConfirmPassword);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.lblStaffID);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "SignupForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Better Limited - Sign Up";
            this.Load += new System.EventHandler(this.SignupForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picShowPassword)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picShowCPassword)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblStaffID;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblConfirmPassword;
        private System.Windows.Forms.TextBox txtStaffID;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtConfirmPassword;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSignup;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblEmailWarning;
        private System.Windows.Forms.Label lblCPasswordWarning;
        private System.Windows.Forms.Label lblPasswordWarning;
        private System.Windows.Forms.Label lblUsernameWarning;
        private System.Windows.Forms.Label lblStaffIDWarning;
        private System.Windows.Forms.PictureBox picShowPassword;
        private System.Windows.Forms.PictureBox picShowCPassword;
        private System.Windows.Forms.Label lblLowercase;
        private System.Windows.Forms.Label lblNumber;
        private System.Windows.Forms.Label lblUppercase;
        private System.Windows.Forms.Label lblSymbols;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
    }
}