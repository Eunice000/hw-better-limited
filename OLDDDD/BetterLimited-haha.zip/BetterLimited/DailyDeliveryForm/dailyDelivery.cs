﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace BetterLimited
{
    public partial class dailyDelivery : Form
    {
        MySqlConnection conn = new MySqlConnection("server=localhost;user id =root;password=;database=betterlimited");
        MySqlCommand command;

        public void openConnection()
        {
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
        }

        public void closeConnection()
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
        }

        public void DisplayTable()
        {
            string sql = "SELECT * FROM deliveryorder";
            openConnection();
            command = new MySqlCommand(sql, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(command);
            DataTable tb1 = new DataTable();
            adp.Fill(tb1);
            dataGridView_dealiyDelivery.DataSource = tb1;
            closeConnection();
        }



        public dailyDelivery()
        {
            InitializeComponent();
        }

        private void dailyDelivery_Load(object sender, EventArgs e)
        {
            dateTimePicker__DeliveryDate.Text = DateTime.Now.ToString("yyyy-MM-dd");
            textBox_Nowdate.Text = DateTime.Now.ToString("yyyy-MM-dd");



        }

        private void button_Search_Click(object sender, EventArgs e)
        {
            openConnection();

            string sql = "SELECT * FROM deliveryorder Where DeliveryDate = ' "+dateTimePicker__DeliveryDate.Text+" ';";

            command = new MySqlCommand(sql, conn);

            //command.Parameters.AddWithValue("deliveryDate", dateTimePicker__DeliveryDate.Text);

            MySqlDataAdapter adp = new MySqlDataAdapter(command);
            DataTable tb1 = new DataTable();
            adp.Fill(tb1);
            dataGridView_dealiyDelivery.DataSource = tb1;
            closeConnection();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            openConnection();

            string sql = "SELECT * FROM deliveryorder Where DeliveryDate = '" + dateTimePicker__DeliveryDate.Text +
                "' AND DeliveryTime BETWEEN '09:00:00' and '12:59:59';";

            command = new MySqlCommand(sql, conn);

            //command.Parameters.AddWithValue("deliveryDate", dateTimePicker__DeliveryDate.Text);

            MySqlDataAdapter adp = new MySqlDataAdapter(command);
            DataTable tb1 = new DataTable();
            adp.Fill(tb1);
            dataGridView_dealiyDelivery.DataSource = tb1;
            closeConnection();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openConnection();

            string sql = "SELECT * FROM deliveryorder Where DeliveryDate = '" + dateTimePicker__DeliveryDate.Text +
                "' AND DeliveryTime BETWEEN '13:00:00' and '17:59:59';";

            command = new MySqlCommand(sql, conn);

            //command.Parameters.AddWithValue("deliveryDate", dateTimePicker__DeliveryDate.Text);

            MySqlDataAdapter adp = new MySqlDataAdapter(command);
            DataTable tb1 = new DataTable();
            adp.Fill(tb1);
            dataGridView_dealiyDelivery.DataSource = tb1;
            closeConnection();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            openConnection();

            string sql = "SELECT * FROM deliveryorder Where DeliveryDate = '" + dateTimePicker__DeliveryDate.Text +
                "' AND DeliveryTime BETWEEN '18:00:00' and '22:59:59';";

            command = new MySqlCommand(sql, conn);

            //command.Parameters.AddWithValue("deliveryDate", dateTimePicker__DeliveryDate.Text);

            MySqlDataAdapter adp = new MySqlDataAdapter(command);
            DataTable tb1 = new DataTable();
            adp.Fill(tb1);
            dataGridView_dealiyDelivery.DataSource = tb1;
            closeConnection();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            openConnection();

            string sql = "SELECT * FROM deliveryorder Where DeliveryDate = ' " + dateTimePicker__DeliveryDate.Text + " ';";

            command = new MySqlCommand(sql, conn);

            //command.Parameters.AddWithValue("deliveryDate", dateTimePicker__DeliveryDate.Text);

            MySqlDataAdapter adp = new MySqlDataAdapter(command);
            DataTable tb1 = new DataTable();
            adp.Fill(tb1);
            dataGridView_dealiyDelivery.DataSource = tb1;
            closeConnection();
        }
    }
}
