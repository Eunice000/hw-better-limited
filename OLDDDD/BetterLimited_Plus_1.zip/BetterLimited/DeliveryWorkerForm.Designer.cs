﻿
namespace BetterLimited
{
    partial class DeliveryWorkerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView_WorkerTable = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EditButton = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label7 = new System.Windows.Forms.Label();
            this.button_clear_Worker = new System.Windows.Forms.Button();
            this.button_Search_Worker = new System.Windows.Forms.Button();
            this.textBox_Search_Worker = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_WorkerTable)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1072, 109);
            this.panel1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(39, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(513, 43);
            this.label2.TabIndex = 14;
            this.label2.Text = "Delivery Workman Managment";
            // 
            // dataGridView_WorkerTable
            // 
            this.dataGridView_WorkerTable.AllowUserToAddRows = false;
            this.dataGridView_WorkerTable.AllowUserToDeleteRows = false;
            this.dataGridView_WorkerTable.AllowUserToResizeRows = false;
            this.dataGridView_WorkerTable.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_WorkerTable.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_WorkerTable.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_WorkerTable.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView_WorkerTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_WorkerTable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.EditButton});
            this.dataGridView_WorkerTable.GridColor = System.Drawing.Color.White;
            this.dataGridView_WorkerTable.Location = new System.Drawing.Point(28, 160);
            this.dataGridView_WorkerTable.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView_WorkerTable.Name = "dataGridView_WorkerTable";
            this.dataGridView_WorkerTable.ReadOnly = true;
            this.dataGridView_WorkerTable.RowHeadersVisible = false;
            this.dataGridView_WorkerTable.RowHeadersWidth = 51;
            this.dataGridView_WorkerTable.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView_WorkerTable.RowTemplate.Height = 27;
            this.dataGridView_WorkerTable.ShowEditingIcon = false;
            this.dataGridView_WorkerTable.Size = new System.Drawing.Size(1014, 135);
            this.dataGridView_WorkerTable.TabIndex = 15;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "StaffID";
            this.Column1.HeaderText = "StaffID";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "StaffName";
            this.Column2.HeaderText = "StaffName";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "Gender";
            this.Column3.HeaderText = "Gender";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "Tel";
            this.Column4.HeaderText = "Tel";
            this.Column4.MinimumWidth = 6;
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "Email";
            this.Column5.HeaderText = "Email";
            this.Column5.MinimumWidth = 6;
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // EditButton
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("PMingLiU-ExtB", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            this.EditButton.DefaultCellStyle = dataGridViewCellStyle3;
            this.EditButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EditButton.HeaderText = "";
            this.EditButton.MinimumWidth = 6;
            this.EditButton.Name = "EditButton";
            this.EditButton.ReadOnly = true;
            this.EditButton.Text = "Select";
            this.EditButton.UseColumnTextForButtonValue = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(660, 136);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 15);
            this.label7.TabIndex = 22;
            this.label7.Text = "ItemID :";
            // 
            // button_clear_Worker
            // 
            this.button_clear_Worker.Location = new System.Drawing.Point(548, 131);
            this.button_clear_Worker.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_clear_Worker.Name = "button_clear_Worker";
            this.button_clear_Worker.Size = new System.Drawing.Size(107, 25);
            this.button_clear_Worker.TabIndex = 21;
            this.button_clear_Worker.Text = "Clear";
            this.button_clear_Worker.UseVisualStyleBackColor = true;
            this.button_clear_Worker.Click += new System.EventHandler(this.button_clear_Worker_Click);
            // 
            // button_Search_Worker
            // 
            this.button_Search_Worker.Location = new System.Drawing.Point(935, 131);
            this.button_Search_Worker.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Search_Worker.Name = "button_Search_Worker";
            this.button_Search_Worker.Size = new System.Drawing.Size(107, 25);
            this.button_Search_Worker.TabIndex = 20;
            this.button_Search_Worker.Text = "Search";
            this.button_Search_Worker.UseVisualStyleBackColor = true;
            this.button_Search_Worker.Click += new System.EventHandler(this.button_Search_Worker_Click);
            // 
            // textBox_Search_Worker
            // 
            this.textBox_Search_Worker.Location = new System.Drawing.Point(732, 131);
            this.textBox_Search_Worker.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_Search_Worker.Name = "textBox_Search_Worker";
            this.textBox_Search_Worker.Size = new System.Drawing.Size(196, 25);
            this.textBox_Search_Worker.TabIndex = 19;
            // 
            // DeliveryWorkerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1072, 730);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button_clear_Worker);
            this.Controls.Add(this.button_Search_Worker);
            this.Controls.Add(this.textBox_Search_Worker);
            this.Controls.Add(this.dataGridView_WorkerTable);
            this.Controls.Add(this.panel1);
            this.Name = "DeliveryWorkerForm";
            this.Text = "DeliveryWorkerForm";
            this.Load += new System.EventHandler(this.DeliveryWorkerForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_WorkerTable)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView_WorkerTable;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewButtonColumn EditButton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button_clear_Worker;
        private System.Windows.Forms.Button button_Search_Worker;
        private System.Windows.Forms.TextBox textBox_Search_Worker;
    }
}