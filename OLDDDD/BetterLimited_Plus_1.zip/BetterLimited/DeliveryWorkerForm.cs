﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace BetterLimited
{
    public partial class DeliveryWorkerForm : Form
    {
        MySqlConnection conn = new MySqlConnection("server=localhost;user id =root;password=;database=betterlimited");
        MySqlCommand command;
        string staffID, department, position;

        public string setDepartment
        {
            set
            {
                department = value;
            }
        }

        public string getDepartment
        {
            get
            {
                return department;
            }
        }
        public string setPosition
        {
            set
            {
                position = value;
            }
        }

        public string getPosition
        {
            get
            {
                return position;
            }
        }


        public void closeConnection()
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
        }


        public void openConnection()
        {
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
        }



        public DeliveryWorkerForm()
        {
            InitializeComponent();
        }

        private void button_clear_Worker_Click(object sender, EventArgs e)
        {
            textBox_Search_Worker.Text = "";
            string sql = "SELECT StaffID,StaffName,Gender,Tel,Email FROM staff WHERE Position = 'Delivery Workman';";
            openConnection();
            command = new MySqlCommand(sql, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(command);
            DataTable tb1 = new DataTable();
            adp.Fill(tb1);
            dataGridView_WorkerTable.DataSource = tb1;
            closeConnection();
        }

        private void DeliveryWorkerForm_Load(object sender, EventArgs e)
        {
            DisplayTable();
        }

        private void DisplayTable()
        {
            string sql = "SELECT StaffID,StaffName,Gender,Tel,Email FROM staff WHERE Position = 'Delivery Workman';";
            openConnection();
            command = new MySqlCommand(sql, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(command);
            DataTable tb1 = new DataTable();
            adp.Fill(tb1);
            dataGridView_WorkerTable.DataSource = tb1;
            closeConnection();
        }



        private void button_Search_Worker_Click(object sender, EventArgs e)
        {
            string sql;

            if (textBox_Search_Worker.Text == "")
            {
                sql = "SELECT StaffID,StaffName,Gender,Tel,Email FROM staff WHERE Position = 'Workman';";
            }
            else
            {
                sql = "SELECT StaffID,StaffName,Gender,Tel,Email FROM staff " +
                    "WHERE Position = 'Delivery Workman' AND StaffID = " + textBox_Search_Worker.Text + ";";
            }
            openConnection();
            command = new MySqlCommand(sql, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(command);
            DataTable tb1 = new DataTable();
            adp.Fill(tb1);
            dataGridView_WorkerTable.DataSource = tb1;
            closeConnection();
        }
    }
}
