﻿
namespace BetterLimited
{
    partial class MenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuForm));
            this.Bar_2 = new System.Windows.Forms.Label();
            this.Bar_1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Label_UserName = new System.Windows.Forms.Label();
            this.Label_UserPosition = new System.Windows.Forms.Label();
            this.Label_UserDepartment = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button_AccountSetting = new System.Windows.Forms.Button();
            this.button_LogOut = new System.Windows.Forms.Button();
            this.button_Language = new System.Windows.Forms.Button();
            this.Lable_Munebar = new System.Windows.Forms.FlowLayoutPanel();
            this.button_AccountingDepart = new System.Windows.Forms.Button();
            this.flPanel_AccountDepart = new System.Windows.Forms.FlowLayoutPanel();
            this.button_ProductManageModule_Accounting = new System.Windows.Forms.Button();
            this.button_AccountingAnalysisModule_Accounting = new System.Windows.Forms.Button();
            this.button_InventoryStorckMangementModul_Account = new System.Windows.Forms.Button();
            this.button_PurchaseDepart = new System.Windows.Forms.Button();
            this.flPanel_PurchaseDepart = new System.Windows.Forms.FlowLayoutPanel();
            this.button_InventoryStorckMangementModule_Purchase = new System.Windows.Forms.Button();
            this.button_AccountingAnalysisModule_Purchase = new System.Windows.Forms.Button();
            this.button_ProductManageModule_Purchase = new System.Windows.Forms.Button();
            this.button_SalesDepart = new System.Windows.Forms.Button();
            this.flPanel_SalesDepart = new System.Windows.Forms.FlowLayoutPanel();
            this.button_ProductManageModule_Sales = new System.Windows.Forms.Button();
            this.button_AccountingAnalysisModule_Sales = new System.Windows.Forms.Button();
            this.button_RetailStorckManageModule_Sales = new System.Windows.Forms.Button();
            this.button_POSModule_Sales = new System.Windows.Forms.Button();
            this.button_ReturnItemsModule_Sales = new System.Windows.Forms.Button();
            this.button_TechnicalDepart = new System.Windows.Forms.Button();
            this.flPanel_TechnicalDepart = new System.Windows.Forms.FlowLayoutPanel();
            this.button_AccountingAnalysisModule_Technical = new System.Windows.Forms.Button();
            this.button_DeliverAndInstallModule_Technical = new System.Windows.Forms.Button();
            this.button_InventoryDepart = new System.Windows.Forms.Button();
            this.flPanel_InventoryDepart = new System.Windows.Forms.FlowLayoutPanel();
            this.button_DeliveryInstallationModule_Inventory = new System.Windows.Forms.Button();
            this.button_AccountingAnalysisModule_Inventory = new System.Windows.Forms.Button();
            this.button_InventoryStorckMangementModule_Inventory = new System.Windows.Forms.Button();
            this.button_RetailStorckManageModule_Inventory = new System.Windows.Forms.Button();
            this.button_ReturnItemModule_Inventory = new System.Windows.Forms.Button();
            this.flpanel_AccountFuntion = new System.Windows.Forms.FlowLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.flpanel_Account_ISMM = new System.Windows.Forms.FlowLayoutPanel();
            this.button_Function_AccountGoodsReceivedNote = new System.Windows.Forms.Button();
            this.button_Function_AccountPurchaseInvoice = new System.Windows.Forms.Button();
            this.button_Function_AccountPurchaseOrder = new System.Windows.Forms.Button();
            this.flpanel_Account_PMM = new System.Windows.Forms.FlowLayoutPanel();
            this.button_Function_AccountItemList = new System.Windows.Forms.Button();
            this.button_Function_AccountUpdateRequest = new System.Windows.Forms.Button();
            this.button_Function_AccountUpdateRequestRecord = new System.Windows.Forms.Button();
            this.flpanel_Account_AAM = new System.Windows.Forms.FlowLayoutPanel();
            this.button_Function_AccountAnalysisReport = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button_Function_AccountItemList2 = new System.Windows.Forms.Button();
            this.button_Function_AccountPurchaseOrder2 = new System.Windows.Forms.Button();
            this.button_Function_AccountGoodsReceivedNote2 = new System.Windows.Forms.Button();
            this.button_Function_AccountPurchaseInvoice2 = new System.Windows.Forms.Button();
            this.button_Function_AccountGoodsReturnedNote = new System.Windows.Forms.Button();
            this.flpanel_Account_RIM = new System.Windows.Forms.FlowLayoutPanel();
            this.button_Function_AccountGoodsReturnedRecord = new System.Windows.Forms.Button();
            this.flpanel_Function = new System.Windows.Forms.FlowLayoutPanel();
            this.flpanel_PurchaseFuntion = new System.Windows.Forms.FlowLayoutPanel();
            this.label8 = new System.Windows.Forms.Label();
            this.flpanel_Purchase_ISMM = new System.Windows.Forms.FlowLayoutPanel();
            this.button_Function_PurchasingReorderRequest = new System.Windows.Forms.Button();
            this.button_Function_PurchasingPurchaseOrder = new System.Windows.Forms.Button();
            this.button_Function_PurchasingGoodsReceivedNote = new System.Windows.Forms.Button();
            this.button_Function_PurchasePurchaseInvoice = new System.Windows.Forms.Button();
            this.flpanel_Purchase_PMM = new System.Windows.Forms.FlowLayoutPanel();
            this.button_Function_PurchaseItemList = new System.Windows.Forms.Button();
            this.button_Function_PurchaseUpdateRequest = new System.Windows.Forms.Button();
            this.button_Function_PurchaseUpdateRequestRecord = new System.Windows.Forms.Button();
            this.flpanel_Purchase_AAM = new System.Windows.Forms.FlowLayoutPanel();
            this.button_Function_PurchaseAnalysisReport = new System.Windows.Forms.Button();
            this.flpanel_SalesFuntion = new System.Windows.Forms.FlowLayoutPanel();
            this.label9 = new System.Windows.Forms.Label();
            this.flpanel_Sales_POS = new System.Windows.Forms.FlowLayoutPanel();
            this.button_SalesPOS = new System.Windows.Forms.Button();
            this.flpanel_Sales_RSMM = new System.Windows.Forms.FlowLayoutPanel();
            this.button_Function_SalesItemList = new System.Windows.Forms.Button();
            this.button_Function_SalesInventoryStorckLevel = new System.Windows.Forms.Button();
            this.button_Function_SalesStorckLevel = new System.Windows.Forms.Button();
            this.button_Function_SalesInventoryList = new System.Windows.Forms.Button();
            this.button_Function_SalesReRestockRequest = new System.Windows.Forms.Button();
            this.flpanel_Sales_PMM = new System.Windows.Forms.FlowLayoutPanel();
            this.button_Function_SalesItemList2 = new System.Windows.Forms.Button();
            this.button_Function_SalesUpdateRequest = new System.Windows.Forms.Button();
            this.button_Function_SalesUpdateRequestRecord = new System.Windows.Forms.Button();
            this.flpanel_Sales_AAM = new System.Windows.Forms.FlowLayoutPanel();
            this.button_Function_SalesAnalysisReport = new System.Windows.Forms.Button();
            this.flpanel_Sales_RIM = new System.Windows.Forms.FlowLayoutPanel();
            this.button_Function_SalesGoodsReturnedRecord = new System.Windows.Forms.Button();
            this.flpanel_TechnicalFuntion = new System.Windows.Forms.FlowLayoutPanel();
            this.label10 = new System.Windows.Forms.Label();
            this.flpanel_Technical_AAM = new System.Windows.Forms.FlowLayoutPanel();
            this.button_Function_TechnicalAnalysisReport = new System.Windows.Forms.Button();
            this.flpanel_Technical_DIM = new System.Windows.Forms.FlowLayoutPanel();
            this.button_Function_TechnicalWorkmenInfoRecord = new System.Windows.Forms.Button();
            this.button_Function_TechnicalWorkmenDutyRecord = new System.Windows.Forms.Button();
            this.button_Function_TechnicalInstallationArrangement = new System.Windows.Forms.Button();
            this.flpanel_InventoryFuntion = new System.Windows.Forms.FlowLayoutPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.flpanel_Inventory_DIM = new System.Windows.Forms.FlowLayoutPanel();
            this.button_Function_InventoryWorkmenInfoRecord = new System.Windows.Forms.Button();
            this.button_Function_InventoryWorkmenDutyRecord = new System.Windows.Forms.Button();
            this.button_Function_InventoryDeliveryArrangement = new System.Windows.Forms.Button();
            this.flpanel_Inventory_AAM = new System.Windows.Forms.FlowLayoutPanel();
            this.button_Function_InventoryAnalysisReport = new System.Windows.Forms.Button();
            this.flpanel_Inventory_RIM = new System.Windows.Forms.FlowLayoutPanel();
            this.button_Function_InventoryGoodsReturnedRecord = new System.Windows.Forms.Button();
            this.flpanel_Inventory_ISMM = new System.Windows.Forms.FlowLayoutPanel();
            this.button_Function_InventoryInventoryStorckLevel = new System.Windows.Forms.Button();
            this.button_Function_InventoryReorderRequest = new System.Windows.Forms.Button();
            this.button_Function_InventoryPurchaseOrder = new System.Windows.Forms.Button();
            this.button_Function_InventoryGoodsReceivedNote = new System.Windows.Forms.Button();
            this.flpanel_Inventory_RSMM = new System.Windows.Forms.FlowLayoutPanel();
            this.button_Function_InventoryInventoryStorckLevel2 = new System.Windows.Forms.Button();
            this.lblStaffID = new System.Windows.Forms.Label();
            this.Lable_Munebar.SuspendLayout();
            this.flPanel_AccountDepart.SuspendLayout();
            this.flPanel_PurchaseDepart.SuspendLayout();
            this.flPanel_SalesDepart.SuspendLayout();
            this.flPanel_TechnicalDepart.SuspendLayout();
            this.flPanel_InventoryDepart.SuspendLayout();
            this.flpanel_AccountFuntion.SuspendLayout();
            this.flpanel_Account_ISMM.SuspendLayout();
            this.flpanel_Account_PMM.SuspendLayout();
            this.flpanel_Account_AAM.SuspendLayout();
            this.flpanel_Account_RIM.SuspendLayout();
            this.flpanel_Function.SuspendLayout();
            this.flpanel_PurchaseFuntion.SuspendLayout();
            this.flpanel_Purchase_ISMM.SuspendLayout();
            this.flpanel_Purchase_PMM.SuspendLayout();
            this.flpanel_Purchase_AAM.SuspendLayout();
            this.flpanel_SalesFuntion.SuspendLayout();
            this.flpanel_Sales_POS.SuspendLayout();
            this.flpanel_Sales_RSMM.SuspendLayout();
            this.flpanel_Sales_PMM.SuspendLayout();
            this.flpanel_Sales_AAM.SuspendLayout();
            this.flpanel_Sales_RIM.SuspendLayout();
            this.flpanel_TechnicalFuntion.SuspendLayout();
            this.flpanel_Technical_AAM.SuspendLayout();
            this.flpanel_Technical_DIM.SuspendLayout();
            this.flpanel_InventoryFuntion.SuspendLayout();
            this.flpanel_Inventory_DIM.SuspendLayout();
            this.flpanel_Inventory_AAM.SuspendLayout();
            this.flpanel_Inventory_RIM.SuspendLayout();
            this.flpanel_Inventory_ISMM.SuspendLayout();
            this.flpanel_Inventory_RSMM.SuspendLayout();
            this.SuspendLayout();
            // 
            // Bar_2
            // 
            this.Bar_2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Bar_2.Dock = System.Windows.Forms.DockStyle.Top;
            this.Bar_2.Location = new System.Drawing.Point(259, 0);
            this.Bar_2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Bar_2.Name = "Bar_2";
            this.Bar_2.Size = new System.Drawing.Size(1073, 102);
            this.Bar_2.TabIndex = 0;
            this.Bar_2.Text = "\r\n";
            // 
            // Bar_1
            // 
            this.Bar_1.BackColor = System.Drawing.SystemColors.Highlight;
            this.Bar_1.Dock = System.Windows.Forms.DockStyle.Left;
            this.Bar_1.Location = new System.Drawing.Point(0, 0);
            this.Bar_1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Bar_1.Name = "Bar_1";
            this.Bar_1.Size = new System.Drawing.Size(259, 849);
            this.Bar_1.TabIndex = 1;
            this.Bar_1.Text = "\r\n";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Highlight;
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 34);
            this.label1.TabIndex = 2;
            this.label1.Text = "Better Limited";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Font = new System.Drawing.Font("Microsoft JhengHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(-3, 94);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(270, 8);
            this.label3.TabIndex = 4;
            // 
            // Label_UserName
            // 
            this.Label_UserName.AutoSize = true;
            this.Label_UserName.BackColor = System.Drawing.SystemColors.Highlight;
            this.Label_UserName.Font = new System.Drawing.Font("Microsoft JhengHei", 15F);
            this.Label_UserName.Location = new System.Drawing.Point(9, 151);
            this.Label_UserName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label_UserName.Name = "Label_UserName";
            this.Label_UserName.Size = new System.Drawing.Size(113, 25);
            this.Label_UserName.TabIndex = 5;
            this.Label_UserName.Text = "Pater Chan";
            // 
            // Label_UserPosition
            // 
            this.Label_UserPosition.AutoSize = true;
            this.Label_UserPosition.BackColor = System.Drawing.SystemColors.Highlight;
            this.Label_UserPosition.Font = new System.Drawing.Font("Microsoft JhengHei", 15F);
            this.Label_UserPosition.Location = new System.Drawing.Point(9, 126);
            this.Label_UserPosition.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label_UserPosition.Name = "Label_UserPosition";
            this.Label_UserPosition.Size = new System.Drawing.Size(96, 25);
            this.Label_UserPosition.TabIndex = 6;
            this.Label_UserPosition.Text = "Manager";
            // 
            // Label_UserDepartment
            // 
            this.Label_UserDepartment.AutoSize = true;
            this.Label_UserDepartment.BackColor = System.Drawing.SystemColors.Highlight;
            this.Label_UserDepartment.Font = new System.Drawing.Font("Microsoft JhengHei", 15F);
            this.Label_UserDepartment.Location = new System.Drawing.Point(9, 102);
            this.Label_UserDepartment.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label_UserDepartment.Name = "Label_UserDepartment";
            this.Label_UserDepartment.Size = new System.Drawing.Size(169, 25);
            this.Label_UserDepartment.TabIndex = 7;
            this.Label_UserDepartment.Text = "XXX Department";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Font = new System.Drawing.Font("Microsoft JhengHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(-3, 189);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(262, 8);
            this.label4.TabIndex = 8;
            // 
            // button_AccountSetting
            // 
            this.button_AccountSetting.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_AccountSetting.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button_AccountSetting.Font = new System.Drawing.Font("Microsoft YaHei", 9F);
            this.button_AccountSetting.Location = new System.Drawing.Point(8, 756);
            this.button_AccountSetting.Margin = new System.Windows.Forms.Padding(2);
            this.button_AccountSetting.Name = "button_AccountSetting";
            this.button_AccountSetting.Size = new System.Drawing.Size(224, 32);
            this.button_AccountSetting.TabIndex = 0;
            this.button_AccountSetting.Text = "AccountSetting";
            this.button_AccountSetting.UseVisualStyleBackColor = false;
            // 
            // button_LogOut
            // 
            this.button_LogOut.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_LogOut.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button_LogOut.Font = new System.Drawing.Font("Microsoft YaHei", 9F);
            this.button_LogOut.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button_LogOut.Location = new System.Drawing.Point(8, 793);
            this.button_LogOut.Margin = new System.Windows.Forms.Padding(2);
            this.button_LogOut.Name = "button_LogOut";
            this.button_LogOut.Size = new System.Drawing.Size(224, 32);
            this.button_LogOut.TabIndex = 10;
            this.button_LogOut.Text = "LogOut";
            this.button_LogOut.UseVisualStyleBackColor = false;
            // 
            // button_Language
            // 
            this.button_Language.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_Language.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button_Language.Font = new System.Drawing.Font("Microsoft YaHei", 9F);
            this.button_Language.Location = new System.Drawing.Point(8, 830);
            this.button_Language.Margin = new System.Windows.Forms.Padding(2);
            this.button_Language.Name = "button_Language";
            this.button_Language.Size = new System.Drawing.Size(224, 32);
            this.button_Language.TabIndex = 11;
            this.button_Language.Text = "Language";
            this.button_Language.UseVisualStyleBackColor = false;
            // 
            // Lable_Munebar
            // 
            this.Lable_Munebar.AutoScroll = true;
            this.Lable_Munebar.BackColor = System.Drawing.SystemColors.Highlight;
            this.Lable_Munebar.Controls.Add(this.button_AccountingDepart);
            this.Lable_Munebar.Controls.Add(this.flPanel_AccountDepart);
            this.Lable_Munebar.Controls.Add(this.button_PurchaseDepart);
            this.Lable_Munebar.Controls.Add(this.flPanel_PurchaseDepart);
            this.Lable_Munebar.Controls.Add(this.button_SalesDepart);
            this.Lable_Munebar.Controls.Add(this.flPanel_SalesDepart);
            this.Lable_Munebar.Controls.Add(this.button_TechnicalDepart);
            this.Lable_Munebar.Controls.Add(this.flPanel_TechnicalDepart);
            this.Lable_Munebar.Controls.Add(this.button_InventoryDepart);
            this.Lable_Munebar.Controls.Add(this.flPanel_InventoryDepart);
            this.Lable_Munebar.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.Lable_Munebar.Location = new System.Drawing.Point(2, 199);
            this.Lable_Munebar.Margin = new System.Windows.Forms.Padding(2);
            this.Lable_Munebar.Name = "Lable_Munebar";
            this.Lable_Munebar.Size = new System.Drawing.Size(250, 378);
            this.Lable_Munebar.TabIndex = 12;
            this.Lable_Munebar.WrapContents = false;
            // 
            // button_AccountingDepart
            // 
            this.button_AccountingDepart.BackColor = System.Drawing.Color.DarkOrange;
            this.button_AccountingDepart.Font = new System.Drawing.Font("Microsoft YaHei", 9F);
            this.button_AccountingDepart.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_AccountingDepart.Location = new System.Drawing.Point(2, 2);
            this.button_AccountingDepart.Margin = new System.Windows.Forms.Padding(2);
            this.button_AccountingDepart.Name = "button_AccountingDepart";
            this.button_AccountingDepart.Size = new System.Drawing.Size(221, 38);
            this.button_AccountingDepart.TabIndex = 44;
            this.button_AccountingDepart.Text = "Accounting Department";
            this.button_AccountingDepart.UseVisualStyleBackColor = false;
            this.button_AccountingDepart.Click += new System.EventHandler(this.button_AccountingDepart_Click);
            // 
            // flPanel_AccountDepart
            // 
            this.flPanel_AccountDepart.AutoSize = true;
            this.flPanel_AccountDepart.Controls.Add(this.button_ProductManageModule_Accounting);
            this.flPanel_AccountDepart.Controls.Add(this.button_AccountingAnalysisModule_Accounting);
            this.flPanel_AccountDepart.Controls.Add(this.button_InventoryStorckMangementModul_Account);
            this.flPanel_AccountDepart.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flPanel_AccountDepart.Location = new System.Drawing.Point(2, 44);
            this.flPanel_AccountDepart.Margin = new System.Windows.Forms.Padding(2);
            this.flPanel_AccountDepart.Name = "flPanel_AccountDepart";
            this.flPanel_AccountDepart.Size = new System.Drawing.Size(225, 84);
            this.flPanel_AccountDepart.TabIndex = 22;
            // 
            // button_ProductManageModule_Accounting
            // 
            this.button_ProductManageModule_Accounting.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_ProductManageModule_Accounting.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ProductManageModule_Accounting.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_ProductManageModule_Accounting.Location = new System.Drawing.Point(2, 2);
            this.button_ProductManageModule_Accounting.Margin = new System.Windows.Forms.Padding(2);
            this.button_ProductManageModule_Accounting.Name = "button_ProductManageModule_Accounting";
            this.button_ProductManageModule_Accounting.Size = new System.Drawing.Size(221, 24);
            this.button_ProductManageModule_Accounting.TabIndex = 35;
            this.button_ProductManageModule_Accounting.Text = "Product Management Module";
            this.button_ProductManageModule_Accounting.UseVisualStyleBackColor = false;
            this.button_ProductManageModule_Accounting.Click += new System.EventHandler(this.button_ProductManageModule_Accounting_Click);
            // 
            // button_AccountingAnalysisModule_Accounting
            // 
            this.button_AccountingAnalysisModule_Accounting.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_AccountingAnalysisModule_Accounting.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_AccountingAnalysisModule_Accounting.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_AccountingAnalysisModule_Accounting.Location = new System.Drawing.Point(2, 30);
            this.button_AccountingAnalysisModule_Accounting.Margin = new System.Windows.Forms.Padding(2);
            this.button_AccountingAnalysisModule_Accounting.Name = "button_AccountingAnalysisModule_Accounting";
            this.button_AccountingAnalysisModule_Accounting.Size = new System.Drawing.Size(221, 24);
            this.button_AccountingAnalysisModule_Accounting.TabIndex = 41;
            this.button_AccountingAnalysisModule_Accounting.Text = "Accounting Analysis Module";
            this.button_AccountingAnalysisModule_Accounting.UseVisualStyleBackColor = false;
            this.button_AccountingAnalysisModule_Accounting.Click += new System.EventHandler(this.button_AccountingAnalysisModule_Accounting_Click);
            // 
            // button_InventoryStorckMangementModul_Account
            // 
            this.button_InventoryStorckMangementModul_Account.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_InventoryStorckMangementModul_Account.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_InventoryStorckMangementModul_Account.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_InventoryStorckMangementModul_Account.Location = new System.Drawing.Point(2, 58);
            this.button_InventoryStorckMangementModul_Account.Margin = new System.Windows.Forms.Padding(2);
            this.button_InventoryStorckMangementModul_Account.Name = "button_InventoryStorckMangementModul_Account";
            this.button_InventoryStorckMangementModul_Account.Size = new System.Drawing.Size(221, 24);
            this.button_InventoryStorckMangementModul_Account.TabIndex = 29;
            this.button_InventoryStorckMangementModul_Account.Text = "Inventory Storck Mangement Module";
            this.button_InventoryStorckMangementModul_Account.UseVisualStyleBackColor = false;
            this.button_InventoryStorckMangementModul_Account.Click += new System.EventHandler(this.button_InventoryStorckMangementModule_Accounting_Click_1);
            // 
            // button_PurchaseDepart
            // 
            this.button_PurchaseDepart.BackColor = System.Drawing.Color.DarkOrange;
            this.button_PurchaseDepart.Font = new System.Drawing.Font("Microsoft YaHei", 9F);
            this.button_PurchaseDepart.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_PurchaseDepart.Location = new System.Drawing.Point(2, 132);
            this.button_PurchaseDepart.Margin = new System.Windows.Forms.Padding(2);
            this.button_PurchaseDepart.Name = "button_PurchaseDepart";
            this.button_PurchaseDepart.Size = new System.Drawing.Size(221, 38);
            this.button_PurchaseDepart.TabIndex = 43;
            this.button_PurchaseDepart.Text = "Purchase Department";
            this.button_PurchaseDepart.UseVisualStyleBackColor = false;
            this.button_PurchaseDepart.Click += new System.EventHandler(this.button_PurchaseDepart_Click);
            // 
            // flPanel_PurchaseDepart
            // 
            this.flPanel_PurchaseDepart.AutoSize = true;
            this.flPanel_PurchaseDepart.Controls.Add(this.button_InventoryStorckMangementModule_Purchase);
            this.flPanel_PurchaseDepart.Controls.Add(this.button_AccountingAnalysisModule_Purchase);
            this.flPanel_PurchaseDepart.Controls.Add(this.button_ProductManageModule_Purchase);
            this.flPanel_PurchaseDepart.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flPanel_PurchaseDepart.Location = new System.Drawing.Point(2, 174);
            this.flPanel_PurchaseDepart.Margin = new System.Windows.Forms.Padding(2);
            this.flPanel_PurchaseDepart.Name = "flPanel_PurchaseDepart";
            this.flPanel_PurchaseDepart.Size = new System.Drawing.Size(225, 84);
            this.flPanel_PurchaseDepart.TabIndex = 42;
            // 
            // button_InventoryStorckMangementModule_Purchase
            // 
            this.button_InventoryStorckMangementModule_Purchase.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_InventoryStorckMangementModule_Purchase.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_InventoryStorckMangementModule_Purchase.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_InventoryStorckMangementModule_Purchase.Location = new System.Drawing.Point(2, 2);
            this.button_InventoryStorckMangementModule_Purchase.Margin = new System.Windows.Forms.Padding(2);
            this.button_InventoryStorckMangementModule_Purchase.Name = "button_InventoryStorckMangementModule_Purchase";
            this.button_InventoryStorckMangementModule_Purchase.Size = new System.Drawing.Size(221, 24);
            this.button_InventoryStorckMangementModule_Purchase.TabIndex = 30;
            this.button_InventoryStorckMangementModule_Purchase.Text = "Inventory Storck Mangement Module";
            this.button_InventoryStorckMangementModule_Purchase.UseVisualStyleBackColor = false;
            this.button_InventoryStorckMangementModule_Purchase.Click += new System.EventHandler(this.button_InventoryStorckMangementModule_Purchase_Click);
            // 
            // button_AccountingAnalysisModule_Purchase
            // 
            this.button_AccountingAnalysisModule_Purchase.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_AccountingAnalysisModule_Purchase.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_AccountingAnalysisModule_Purchase.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_AccountingAnalysisModule_Purchase.Location = new System.Drawing.Point(2, 30);
            this.button_AccountingAnalysisModule_Purchase.Margin = new System.Windows.Forms.Padding(2);
            this.button_AccountingAnalysisModule_Purchase.Name = "button_AccountingAnalysisModule_Purchase";
            this.button_AccountingAnalysisModule_Purchase.Size = new System.Drawing.Size(221, 24);
            this.button_AccountingAnalysisModule_Purchase.TabIndex = 40;
            this.button_AccountingAnalysisModule_Purchase.Text = "Accounting Analysis Module";
            this.button_AccountingAnalysisModule_Purchase.UseVisualStyleBackColor = false;
            this.button_AccountingAnalysisModule_Purchase.Click += new System.EventHandler(this.button_AccountingAnalysisModule_Purchase_Click);
            // 
            // button_ProductManageModule_Purchase
            // 
            this.button_ProductManageModule_Purchase.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_ProductManageModule_Purchase.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ProductManageModule_Purchase.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_ProductManageModule_Purchase.Location = new System.Drawing.Point(2, 58);
            this.button_ProductManageModule_Purchase.Margin = new System.Windows.Forms.Padding(2);
            this.button_ProductManageModule_Purchase.Name = "button_ProductManageModule_Purchase";
            this.button_ProductManageModule_Purchase.Size = new System.Drawing.Size(221, 24);
            this.button_ProductManageModule_Purchase.TabIndex = 36;
            this.button_ProductManageModule_Purchase.Text = "Product Management Module";
            this.button_ProductManageModule_Purchase.UseVisualStyleBackColor = false;
            this.button_ProductManageModule_Purchase.Click += new System.EventHandler(this.button_ProductManageModule_Purchase_Click);
            // 
            // button_SalesDepart
            // 
            this.button_SalesDepart.BackColor = System.Drawing.Color.DarkOrange;
            this.button_SalesDepart.Font = new System.Drawing.Font("Microsoft YaHei", 9F);
            this.button_SalesDepart.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_SalesDepart.Location = new System.Drawing.Point(2, 262);
            this.button_SalesDepart.Margin = new System.Windows.Forms.Padding(2);
            this.button_SalesDepart.Name = "button_SalesDepart";
            this.button_SalesDepart.Size = new System.Drawing.Size(221, 38);
            this.button_SalesDepart.TabIndex = 42;
            this.button_SalesDepart.Text = "SalesDepartment";
            this.button_SalesDepart.UseVisualStyleBackColor = false;
            this.button_SalesDepart.Click += new System.EventHandler(this.button_SalesDepart_Click);
            // 
            // flPanel_SalesDepart
            // 
            this.flPanel_SalesDepart.AutoSize = true;
            this.flPanel_SalesDepart.Controls.Add(this.button_ProductManageModule_Sales);
            this.flPanel_SalesDepart.Controls.Add(this.button_AccountingAnalysisModule_Sales);
            this.flPanel_SalesDepart.Controls.Add(this.button_RetailStorckManageModule_Sales);
            this.flPanel_SalesDepart.Controls.Add(this.button_POSModule_Sales);
            this.flPanel_SalesDepart.Controls.Add(this.button_ReturnItemsModule_Sales);
            this.flPanel_SalesDepart.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flPanel_SalesDepart.Location = new System.Drawing.Point(2, 304);
            this.flPanel_SalesDepart.Margin = new System.Windows.Forms.Padding(2);
            this.flPanel_SalesDepart.Name = "flPanel_SalesDepart";
            this.flPanel_SalesDepart.Size = new System.Drawing.Size(225, 140);
            this.flPanel_SalesDepart.TabIndex = 21;
            // 
            // button_ProductManageModule_Sales
            // 
            this.button_ProductManageModule_Sales.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_ProductManageModule_Sales.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ProductManageModule_Sales.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_ProductManageModule_Sales.Location = new System.Drawing.Point(2, 2);
            this.button_ProductManageModule_Sales.Margin = new System.Windows.Forms.Padding(2);
            this.button_ProductManageModule_Sales.Name = "button_ProductManageModule_Sales";
            this.button_ProductManageModule_Sales.Size = new System.Drawing.Size(221, 24);
            this.button_ProductManageModule_Sales.TabIndex = 34;
            this.button_ProductManageModule_Sales.Text = "Product Management Module";
            this.button_ProductManageModule_Sales.UseVisualStyleBackColor = false;
            this.button_ProductManageModule_Sales.Click += new System.EventHandler(this.button_ProductManageModule_Click);
            // 
            // button_AccountingAnalysisModule_Sales
            // 
            this.button_AccountingAnalysisModule_Sales.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_AccountingAnalysisModule_Sales.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_AccountingAnalysisModule_Sales.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_AccountingAnalysisModule_Sales.Location = new System.Drawing.Point(2, 30);
            this.button_AccountingAnalysisModule_Sales.Margin = new System.Windows.Forms.Padding(2);
            this.button_AccountingAnalysisModule_Sales.Name = "button_AccountingAnalysisModule_Sales";
            this.button_AccountingAnalysisModule_Sales.Size = new System.Drawing.Size(221, 24);
            this.button_AccountingAnalysisModule_Sales.TabIndex = 38;
            this.button_AccountingAnalysisModule_Sales.Text = "Accounting Analysis Module";
            this.button_AccountingAnalysisModule_Sales.UseVisualStyleBackColor = false;
            this.button_AccountingAnalysisModule_Sales.Click += new System.EventHandler(this.button_AccountingAnalysisModule_Sales_Click);
            // 
            // button_RetailStorckManageModule_Sales
            // 
            this.button_RetailStorckManageModule_Sales.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_RetailStorckManageModule_Sales.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_RetailStorckManageModule_Sales.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_RetailStorckManageModule_Sales.Location = new System.Drawing.Point(2, 58);
            this.button_RetailStorckManageModule_Sales.Margin = new System.Windows.Forms.Padding(2);
            this.button_RetailStorckManageModule_Sales.Name = "button_RetailStorckManageModule_Sales";
            this.button_RetailStorckManageModule_Sales.Size = new System.Drawing.Size(221, 24);
            this.button_RetailStorckManageModule_Sales.TabIndex = 24;
            this.button_RetailStorckManageModule_Sales.Text = "Retail Storck Management Module";
            this.button_RetailStorckManageModule_Sales.UseVisualStyleBackColor = false;
            this.button_RetailStorckManageModule_Sales.Click += new System.EventHandler(this.button_RetailStorckManageModule_Click);
            // 
            // button_POSModule_Sales
            // 
            this.button_POSModule_Sales.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_POSModule_Sales.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_POSModule_Sales.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_POSModule_Sales.Location = new System.Drawing.Point(2, 86);
            this.button_POSModule_Sales.Margin = new System.Windows.Forms.Padding(2);
            this.button_POSModule_Sales.Name = "button_POSModule_Sales";
            this.button_POSModule_Sales.Size = new System.Drawing.Size(221, 24);
            this.button_POSModule_Sales.TabIndex = 23;
            this.button_POSModule_Sales.Text = "POS Module";
            this.button_POSModule_Sales.UseVisualStyleBackColor = false;
            this.button_POSModule_Sales.Click += new System.EventHandler(this.button_POSModule_Click);
            // 
            // button_ReturnItemsModule_Sales
            // 
            this.button_ReturnItemsModule_Sales.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_ReturnItemsModule_Sales.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ReturnItemsModule_Sales.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_ReturnItemsModule_Sales.Location = new System.Drawing.Point(2, 114);
            this.button_ReturnItemsModule_Sales.Margin = new System.Windows.Forms.Padding(2);
            this.button_ReturnItemsModule_Sales.Name = "button_ReturnItemsModule_Sales";
            this.button_ReturnItemsModule_Sales.Size = new System.Drawing.Size(221, 24);
            this.button_ReturnItemsModule_Sales.TabIndex = 39;
            this.button_ReturnItemsModule_Sales.Text = "Return Item Module";
            this.button_ReturnItemsModule_Sales.UseVisualStyleBackColor = false;
            this.button_ReturnItemsModule_Sales.Click += new System.EventHandler(this.button_ReturnItemsModule_Sales_Click);
            // 
            // button_TechnicalDepart
            // 
            this.button_TechnicalDepart.BackColor = System.Drawing.Color.DarkOrange;
            this.button_TechnicalDepart.Font = new System.Drawing.Font("Microsoft YaHei", 9F);
            this.button_TechnicalDepart.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_TechnicalDepart.Location = new System.Drawing.Point(2, 448);
            this.button_TechnicalDepart.Margin = new System.Windows.Forms.Padding(2);
            this.button_TechnicalDepart.Name = "button_TechnicalDepart";
            this.button_TechnicalDepart.Size = new System.Drawing.Size(221, 38);
            this.button_TechnicalDepart.TabIndex = 46;
            this.button_TechnicalDepart.Text = "Technical Support Department";
            this.button_TechnicalDepart.UseVisualStyleBackColor = false;
            this.button_TechnicalDepart.Click += new System.EventHandler(this.button_TechnicalDepart_Click);
            // 
            // flPanel_TechnicalDepart
            // 
            this.flPanel_TechnicalDepart.AutoSize = true;
            this.flPanel_TechnicalDepart.Controls.Add(this.button_AccountingAnalysisModule_Technical);
            this.flPanel_TechnicalDepart.Controls.Add(this.button_DeliverAndInstallModule_Technical);
            this.flPanel_TechnicalDepart.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flPanel_TechnicalDepart.Location = new System.Drawing.Point(2, 490);
            this.flPanel_TechnicalDepart.Margin = new System.Windows.Forms.Padding(2);
            this.flPanel_TechnicalDepart.Name = "flPanel_TechnicalDepart";
            this.flPanel_TechnicalDepart.Size = new System.Drawing.Size(225, 56);
            this.flPanel_TechnicalDepart.TabIndex = 43;
            // 
            // button_AccountingAnalysisModule_Technical
            // 
            this.button_AccountingAnalysisModule_Technical.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_AccountingAnalysisModule_Technical.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_AccountingAnalysisModule_Technical.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_AccountingAnalysisModule_Technical.Location = new System.Drawing.Point(2, 2);
            this.button_AccountingAnalysisModule_Technical.Margin = new System.Windows.Forms.Padding(2);
            this.button_AccountingAnalysisModule_Technical.Name = "button_AccountingAnalysisModule_Technical";
            this.button_AccountingAnalysisModule_Technical.Size = new System.Drawing.Size(221, 24);
            this.button_AccountingAnalysisModule_Technical.TabIndex = 37;
            this.button_AccountingAnalysisModule_Technical.Text = "Accounting Analysis Module";
            this.button_AccountingAnalysisModule_Technical.UseVisualStyleBackColor = false;
            this.button_AccountingAnalysisModule_Technical.Click += new System.EventHandler(this.button_AccountingAnalysisModule_Technical_Click);
            // 
            // button_DeliverAndInstallModule_Technical
            // 
            this.button_DeliverAndInstallModule_Technical.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_DeliverAndInstallModule_Technical.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_DeliverAndInstallModule_Technical.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_DeliverAndInstallModule_Technical.Location = new System.Drawing.Point(2, 30);
            this.button_DeliverAndInstallModule_Technical.Margin = new System.Windows.Forms.Padding(2);
            this.button_DeliverAndInstallModule_Technical.Name = "button_DeliverAndInstallModule_Technical";
            this.button_DeliverAndInstallModule_Technical.Size = new System.Drawing.Size(221, 24);
            this.button_DeliverAndInstallModule_Technical.TabIndex = 32;
            this.button_DeliverAndInstallModule_Technical.Text = "Delivery and Installation Module";
            this.button_DeliverAndInstallModule_Technical.UseVisualStyleBackColor = false;
            this.button_DeliverAndInstallModule_Technical.Click += new System.EventHandler(this.button_DeliverAndInstallModule_Technical_Click);
            // 
            // button_InventoryDepart
            // 
            this.button_InventoryDepart.BackColor = System.Drawing.Color.DarkOrange;
            this.button_InventoryDepart.Font = new System.Drawing.Font("Microsoft YaHei", 9F);
            this.button_InventoryDepart.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_InventoryDepart.Location = new System.Drawing.Point(2, 550);
            this.button_InventoryDepart.Margin = new System.Windows.Forms.Padding(2);
            this.button_InventoryDepart.Name = "button_InventoryDepart";
            this.button_InventoryDepart.Size = new System.Drawing.Size(221, 38);
            this.button_InventoryDepart.TabIndex = 45;
            this.button_InventoryDepart.Text = "Inventory Department";
            this.button_InventoryDepart.UseVisualStyleBackColor = false;
            this.button_InventoryDepart.Click += new System.EventHandler(this.button_InventoryDepart_Click);
            // 
            // flPanel_InventoryDepart
            // 
            this.flPanel_InventoryDepart.AutoSize = true;
            this.flPanel_InventoryDepart.Controls.Add(this.button_DeliveryInstallationModule_Inventory);
            this.flPanel_InventoryDepart.Controls.Add(this.button_AccountingAnalysisModule_Inventory);
            this.flPanel_InventoryDepart.Controls.Add(this.button_InventoryStorckMangementModule_Inventory);
            this.flPanel_InventoryDepart.Controls.Add(this.button_RetailStorckManageModule_Inventory);
            this.flPanel_InventoryDepart.Controls.Add(this.button_ReturnItemModule_Inventory);
            this.flPanel_InventoryDepart.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flPanel_InventoryDepart.Location = new System.Drawing.Point(2, 592);
            this.flPanel_InventoryDepart.Margin = new System.Windows.Forms.Padding(2);
            this.flPanel_InventoryDepart.Name = "flPanel_InventoryDepart";
            this.flPanel_InventoryDepart.Size = new System.Drawing.Size(225, 140);
            this.flPanel_InventoryDepart.TabIndex = 44;
            // 
            // button_DeliveryInstallationModule_Inventory
            // 
            this.button_DeliveryInstallationModule_Inventory.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_DeliveryInstallationModule_Inventory.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_DeliveryInstallationModule_Inventory.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_DeliveryInstallationModule_Inventory.Location = new System.Drawing.Point(2, 2);
            this.button_DeliveryInstallationModule_Inventory.Margin = new System.Windows.Forms.Padding(2);
            this.button_DeliveryInstallationModule_Inventory.Name = "button_DeliveryInstallationModule_Inventory";
            this.button_DeliveryInstallationModule_Inventory.Size = new System.Drawing.Size(221, 24);
            this.button_DeliveryInstallationModule_Inventory.TabIndex = 31;
            this.button_DeliveryInstallationModule_Inventory.Text = "Delivery and Installation Module";
            this.button_DeliveryInstallationModule_Inventory.UseVisualStyleBackColor = false;
            this.button_DeliveryInstallationModule_Inventory.Click += new System.EventHandler(this.button_DeliveryInstallationModule_Click);
            // 
            // button_AccountingAnalysisModule_Inventory
            // 
            this.button_AccountingAnalysisModule_Inventory.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_AccountingAnalysisModule_Inventory.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_AccountingAnalysisModule_Inventory.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_AccountingAnalysisModule_Inventory.Location = new System.Drawing.Point(2, 30);
            this.button_AccountingAnalysisModule_Inventory.Margin = new System.Windows.Forms.Padding(2);
            this.button_AccountingAnalysisModule_Inventory.Name = "button_AccountingAnalysisModule_Inventory";
            this.button_AccountingAnalysisModule_Inventory.Size = new System.Drawing.Size(221, 24);
            this.button_AccountingAnalysisModule_Inventory.TabIndex = 39;
            this.button_AccountingAnalysisModule_Inventory.Text = "Accounting Analysis Module";
            this.button_AccountingAnalysisModule_Inventory.UseVisualStyleBackColor = false;
            this.button_AccountingAnalysisModule_Inventory.Click += new System.EventHandler(this.button_AccountingAnalysisModule_Inventory_Click);
            // 
            // button_InventoryStorckMangementModule_Inventory
            // 
            this.button_InventoryStorckMangementModule_Inventory.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_InventoryStorckMangementModule_Inventory.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_InventoryStorckMangementModule_Inventory.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_InventoryStorckMangementModule_Inventory.Location = new System.Drawing.Point(2, 58);
            this.button_InventoryStorckMangementModule_Inventory.Margin = new System.Windows.Forms.Padding(2);
            this.button_InventoryStorckMangementModule_Inventory.Name = "button_InventoryStorckMangementModule_Inventory";
            this.button_InventoryStorckMangementModule_Inventory.Size = new System.Drawing.Size(221, 24);
            this.button_InventoryStorckMangementModule_Inventory.TabIndex = 27;
            this.button_InventoryStorckMangementModule_Inventory.Text = "Inventory Storck Mangement Module";
            this.button_InventoryStorckMangementModule_Inventory.UseVisualStyleBackColor = false;
            this.button_InventoryStorckMangementModule_Inventory.Click += new System.EventHandler(this.button_InventoryStorckMangementModule_Click);
            // 
            // button_RetailStorckManageModule_Inventory
            // 
            this.button_RetailStorckManageModule_Inventory.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_RetailStorckManageModule_Inventory.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_RetailStorckManageModule_Inventory.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_RetailStorckManageModule_Inventory.Location = new System.Drawing.Point(2, 86);
            this.button_RetailStorckManageModule_Inventory.Margin = new System.Windows.Forms.Padding(2);
            this.button_RetailStorckManageModule_Inventory.Name = "button_RetailStorckManageModule_Inventory";
            this.button_RetailStorckManageModule_Inventory.Size = new System.Drawing.Size(221, 24);
            this.button_RetailStorckManageModule_Inventory.TabIndex = 26;
            this.button_RetailStorckManageModule_Inventory.Text = "Retail Storck Management Module";
            this.button_RetailStorckManageModule_Inventory.UseVisualStyleBackColor = false;
            this.button_RetailStorckManageModule_Inventory.Click += new System.EventHandler(this.button_RetailStorckManageModule_Inventory_Click);
            // 
            // button_ReturnItemModule_Inventory
            // 
            this.button_ReturnItemModule_Inventory.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_ReturnItemModule_Inventory.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ReturnItemModule_Inventory.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_ReturnItemModule_Inventory.Location = new System.Drawing.Point(2, 114);
            this.button_ReturnItemModule_Inventory.Margin = new System.Windows.Forms.Padding(2);
            this.button_ReturnItemModule_Inventory.Name = "button_ReturnItemModule_Inventory";
            this.button_ReturnItemModule_Inventory.Size = new System.Drawing.Size(221, 24);
            this.button_ReturnItemModule_Inventory.TabIndex = 40;
            this.button_ReturnItemModule_Inventory.Text = "Return Item Module";
            this.button_ReturnItemModule_Inventory.UseVisualStyleBackColor = false;
            this.button_ReturnItemModule_Inventory.Click += new System.EventHandler(this.button_ReturnItemModule_Inventory_Click);
            // 
            // flpanel_AccountFuntion
            // 
            this.flpanel_AccountFuntion.AutoScroll = true;
            this.flpanel_AccountFuntion.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_AccountFuntion.Controls.Add(this.label7);
            this.flpanel_AccountFuntion.Controls.Add(this.flpanel_Account_ISMM);
            this.flpanel_AccountFuntion.Controls.Add(this.flpanel_Account_PMM);
            this.flpanel_AccountFuntion.Controls.Add(this.flpanel_Account_AAM);
            this.flpanel_AccountFuntion.Controls.Add(this.flpanel_Account_RIM);
            this.flpanel_AccountFuntion.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_AccountFuntion.Location = new System.Drawing.Point(2, 2);
            this.flpanel_AccountFuntion.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_AccountFuntion.Name = "flpanel_AccountFuntion";
            this.flpanel_AccountFuntion.Size = new System.Drawing.Size(416, 638);
            this.flpanel_AccountFuntion.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label7.ForeColor = System.Drawing.SystemColors.Control;
            this.label7.Location = new System.Drawing.Point(2, 0);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(412, 37);
            this.label7.TabIndex = 15;
            this.label7.Text = "Accounting Department";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // flpanel_Account_ISMM
            // 
            this.flpanel_Account_ISMM.AutoSize = true;
            this.flpanel_Account_ISMM.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_Account_ISMM.Controls.Add(this.button_Function_AccountGoodsReceivedNote);
            this.flpanel_Account_ISMM.Controls.Add(this.button_Function_AccountPurchaseInvoice);
            this.flpanel_Account_ISMM.Controls.Add(this.button_Function_AccountPurchaseOrder);
            this.flpanel_Account_ISMM.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_Account_ISMM.Location = new System.Drawing.Point(2, 39);
            this.flpanel_Account_ISMM.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Account_ISMM.Name = "flpanel_Account_ISMM";
            this.flpanel_Account_ISMM.Size = new System.Drawing.Size(411, 123);
            this.flpanel_Account_ISMM.TabIndex = 31;
            // 
            // button_Function_AccountGoodsReceivedNote
            // 
            this.button_Function_AccountGoodsReceivedNote.AutoSize = true;
            this.button_Function_AccountGoodsReceivedNote.Location = new System.Drawing.Point(2, 2);
            this.button_Function_AccountGoodsReceivedNote.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_AccountGoodsReceivedNote.Name = "button_Function_AccountGoodsReceivedNote";
            this.button_Function_AccountGoodsReceivedNote.Size = new System.Drawing.Size(407, 37);
            this.button_Function_AccountGoodsReceivedNote.TabIndex = 33;
            this.button_Function_AccountGoodsReceivedNote.Text = "Goods Received Note";
            this.button_Function_AccountGoodsReceivedNote.UseVisualStyleBackColor = true;
            // 
            // button_Function_AccountPurchaseInvoice
            // 
            this.button_Function_AccountPurchaseInvoice.AutoSize = true;
            this.button_Function_AccountPurchaseInvoice.Location = new System.Drawing.Point(2, 43);
            this.button_Function_AccountPurchaseInvoice.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_AccountPurchaseInvoice.Name = "button_Function_AccountPurchaseInvoice";
            this.button_Function_AccountPurchaseInvoice.Size = new System.Drawing.Size(407, 37);
            this.button_Function_AccountPurchaseInvoice.TabIndex = 26;
            this.button_Function_AccountPurchaseInvoice.Text = "Purchase Invoice";
            this.button_Function_AccountPurchaseInvoice.UseVisualStyleBackColor = true;
            // 
            // button_Function_AccountPurchaseOrder
            // 
            this.button_Function_AccountPurchaseOrder.AutoSize = true;
            this.button_Function_AccountPurchaseOrder.Location = new System.Drawing.Point(2, 84);
            this.button_Function_AccountPurchaseOrder.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_AccountPurchaseOrder.Name = "button_Function_AccountPurchaseOrder";
            this.button_Function_AccountPurchaseOrder.Size = new System.Drawing.Size(407, 37);
            this.button_Function_AccountPurchaseOrder.TabIndex = 32;
            this.button_Function_AccountPurchaseOrder.Text = "Purchase Order";
            this.button_Function_AccountPurchaseOrder.UseVisualStyleBackColor = true;
            // 
            // flpanel_Account_PMM
            // 
            this.flpanel_Account_PMM.AutoSize = true;
            this.flpanel_Account_PMM.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_Account_PMM.Controls.Add(this.button_Function_AccountItemList);
            this.flpanel_Account_PMM.Controls.Add(this.button_Function_AccountUpdateRequest);
            this.flpanel_Account_PMM.Controls.Add(this.button_Function_AccountUpdateRequestRecord);
            this.flpanel_Account_PMM.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_Account_PMM.Location = new System.Drawing.Point(2, 166);
            this.flpanel_Account_PMM.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Account_PMM.Name = "flpanel_Account_PMM";
            this.flpanel_Account_PMM.Size = new System.Drawing.Size(411, 123);
            this.flpanel_Account_PMM.TabIndex = 32;
            // 
            // button_Function_AccountItemList
            // 
            this.button_Function_AccountItemList.AutoSize = true;
            this.button_Function_AccountItemList.Location = new System.Drawing.Point(2, 2);
            this.button_Function_AccountItemList.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_AccountItemList.Name = "button_Function_AccountItemList";
            this.button_Function_AccountItemList.Size = new System.Drawing.Size(407, 37);
            this.button_Function_AccountItemList.TabIndex = 23;
            this.button_Function_AccountItemList.Text = "Item List";
            this.button_Function_AccountItemList.UseVisualStyleBackColor = true;
            // 
            // button_Function_AccountUpdateRequest
            // 
            this.button_Function_AccountUpdateRequest.AutoSize = true;
            this.button_Function_AccountUpdateRequest.Location = new System.Drawing.Point(2, 43);
            this.button_Function_AccountUpdateRequest.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_AccountUpdateRequest.Name = "button_Function_AccountUpdateRequest";
            this.button_Function_AccountUpdateRequest.Size = new System.Drawing.Size(407, 37);
            this.button_Function_AccountUpdateRequest.TabIndex = 26;
            this.button_Function_AccountUpdateRequest.Text = "Update Request";
            this.button_Function_AccountUpdateRequest.UseVisualStyleBackColor = true;
            // 
            // button_Function_AccountUpdateRequestRecord
            // 
            this.button_Function_AccountUpdateRequestRecord.AutoSize = true;
            this.button_Function_AccountUpdateRequestRecord.Location = new System.Drawing.Point(2, 84);
            this.button_Function_AccountUpdateRequestRecord.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_AccountUpdateRequestRecord.Name = "button_Function_AccountUpdateRequestRecord";
            this.button_Function_AccountUpdateRequestRecord.Size = new System.Drawing.Size(407, 37);
            this.button_Function_AccountUpdateRequestRecord.TabIndex = 29;
            this.button_Function_AccountUpdateRequestRecord.Text = "Update Request Record";
            this.button_Function_AccountUpdateRequestRecord.UseVisualStyleBackColor = true;
            // 
            // flpanel_Account_AAM
            // 
            this.flpanel_Account_AAM.AutoSize = true;
            this.flpanel_Account_AAM.Controls.Add(this.button_Function_AccountAnalysisReport);
            this.flpanel_Account_AAM.Controls.Add(this.button1);
            this.flpanel_Account_AAM.Controls.Add(this.button_Function_AccountItemList2);
            this.flpanel_Account_AAM.Controls.Add(this.button_Function_AccountPurchaseOrder2);
            this.flpanel_Account_AAM.Controls.Add(this.button_Function_AccountGoodsReceivedNote2);
            this.flpanel_Account_AAM.Controls.Add(this.button_Function_AccountPurchaseInvoice2);
            this.flpanel_Account_AAM.Controls.Add(this.button_Function_AccountGoodsReturnedNote);
            this.flpanel_Account_AAM.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_Account_AAM.Location = new System.Drawing.Point(2, 293);
            this.flpanel_Account_AAM.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Account_AAM.Name = "flpanel_Account_AAM";
            this.flpanel_Account_AAM.Size = new System.Drawing.Size(411, 287);
            this.flpanel_Account_AAM.TabIndex = 33;
            // 
            // button_Function_AccountAnalysisReport
            // 
            this.button_Function_AccountAnalysisReport.AutoSize = true;
            this.button_Function_AccountAnalysisReport.Location = new System.Drawing.Point(2, 2);
            this.button_Function_AccountAnalysisReport.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_AccountAnalysisReport.Name = "button_Function_AccountAnalysisReport";
            this.button_Function_AccountAnalysisReport.Size = new System.Drawing.Size(407, 37);
            this.button_Function_AccountAnalysisReport.TabIndex = 27;
            this.button_Function_AccountAnalysisReport.Text = "AnalysisReport";
            this.button_Function_AccountAnalysisReport.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.Location = new System.Drawing.Point(2, 43);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(407, 37);
            this.button1.TabIndex = 32;
            this.button1.Text = "Sales Order";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button_Function_AccountItemList2
            // 
            this.button_Function_AccountItemList2.AutoSize = true;
            this.button_Function_AccountItemList2.Location = new System.Drawing.Point(2, 84);
            this.button_Function_AccountItemList2.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_AccountItemList2.Name = "button_Function_AccountItemList2";
            this.button_Function_AccountItemList2.Size = new System.Drawing.Size(407, 37);
            this.button_Function_AccountItemList2.TabIndex = 33;
            this.button_Function_AccountItemList2.Text = "Item List";
            this.button_Function_AccountItemList2.UseVisualStyleBackColor = true;
            // 
            // button_Function_AccountPurchaseOrder2
            // 
            this.button_Function_AccountPurchaseOrder2.AutoSize = true;
            this.button_Function_AccountPurchaseOrder2.Location = new System.Drawing.Point(2, 125);
            this.button_Function_AccountPurchaseOrder2.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_AccountPurchaseOrder2.Name = "button_Function_AccountPurchaseOrder2";
            this.button_Function_AccountPurchaseOrder2.Size = new System.Drawing.Size(407, 37);
            this.button_Function_AccountPurchaseOrder2.TabIndex = 34;
            this.button_Function_AccountPurchaseOrder2.Text = "Purchase Order";
            this.button_Function_AccountPurchaseOrder2.UseVisualStyleBackColor = true;
            // 
            // button_Function_AccountGoodsReceivedNote2
            // 
            this.button_Function_AccountGoodsReceivedNote2.AutoSize = true;
            this.button_Function_AccountGoodsReceivedNote2.Location = new System.Drawing.Point(2, 166);
            this.button_Function_AccountGoodsReceivedNote2.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_AccountGoodsReceivedNote2.Name = "button_Function_AccountGoodsReceivedNote2";
            this.button_Function_AccountGoodsReceivedNote2.Size = new System.Drawing.Size(407, 37);
            this.button_Function_AccountGoodsReceivedNote2.TabIndex = 35;
            this.button_Function_AccountGoodsReceivedNote2.Text = "Goods Received Note";
            this.button_Function_AccountGoodsReceivedNote2.UseVisualStyleBackColor = true;
            // 
            // button_Function_AccountPurchaseInvoice2
            // 
            this.button_Function_AccountPurchaseInvoice2.AutoSize = true;
            this.button_Function_AccountPurchaseInvoice2.Location = new System.Drawing.Point(2, 207);
            this.button_Function_AccountPurchaseInvoice2.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_AccountPurchaseInvoice2.Name = "button_Function_AccountPurchaseInvoice2";
            this.button_Function_AccountPurchaseInvoice2.Size = new System.Drawing.Size(407, 37);
            this.button_Function_AccountPurchaseInvoice2.TabIndex = 36;
            this.button_Function_AccountPurchaseInvoice2.Text = "Purchase Invoice";
            this.button_Function_AccountPurchaseInvoice2.UseVisualStyleBackColor = true;
            // 
            // button_Function_AccountGoodsReturnedNote
            // 
            this.button_Function_AccountGoodsReturnedNote.AutoSize = true;
            this.button_Function_AccountGoodsReturnedNote.Location = new System.Drawing.Point(2, 248);
            this.button_Function_AccountGoodsReturnedNote.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_AccountGoodsReturnedNote.Name = "button_Function_AccountGoodsReturnedNote";
            this.button_Function_AccountGoodsReturnedNote.Size = new System.Drawing.Size(407, 37);
            this.button_Function_AccountGoodsReturnedNote.TabIndex = 37;
            this.button_Function_AccountGoodsReturnedNote.Text = "Goods Returned Note";
            this.button_Function_AccountGoodsReturnedNote.UseVisualStyleBackColor = true;
            // 
            // flpanel_Account_RIM
            // 
            this.flpanel_Account_RIM.AutoSize = true;
            this.flpanel_Account_RIM.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_Account_RIM.Controls.Add(this.button_Function_AccountGoodsReturnedRecord);
            this.flpanel_Account_RIM.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_Account_RIM.Location = new System.Drawing.Point(2, 584);
            this.flpanel_Account_RIM.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Account_RIM.Name = "flpanel_Account_RIM";
            this.flpanel_Account_RIM.Size = new System.Drawing.Size(411, 41);
            this.flpanel_Account_RIM.TabIndex = 34;
            // 
            // button_Function_AccountGoodsReturnedRecord
            // 
            this.button_Function_AccountGoodsReturnedRecord.AutoSize = true;
            this.button_Function_AccountGoodsReturnedRecord.Location = new System.Drawing.Point(2, 2);
            this.button_Function_AccountGoodsReturnedRecord.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_AccountGoodsReturnedRecord.Name = "button_Function_AccountGoodsReturnedRecord";
            this.button_Function_AccountGoodsReturnedRecord.Size = new System.Drawing.Size(407, 37);
            this.button_Function_AccountGoodsReturnedRecord.TabIndex = 27;
            this.button_Function_AccountGoodsReturnedRecord.Text = "Goods Returned Record";
            this.button_Function_AccountGoodsReturnedRecord.UseVisualStyleBackColor = true;
            // 
            // flpanel_Function
            // 
            this.flpanel_Function.AutoScroll = true;
            this.flpanel_Function.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_Function.Controls.Add(this.flpanel_AccountFuntion);
            this.flpanel_Function.Controls.Add(this.flpanel_PurchaseFuntion);
            this.flpanel_Function.Controls.Add(this.flpanel_SalesFuntion);
            this.flpanel_Function.Controls.Add(this.flpanel_TechnicalFuntion);
            this.flpanel_Function.Controls.Add(this.flpanel_InventoryFuntion);
            this.flpanel_Function.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.flpanel_Function.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_Function.Font = new System.Drawing.Font("Microsoft YaHei", 9F);
            this.flpanel_Function.Location = new System.Drawing.Point(591, 112);
            this.flpanel_Function.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Function.Name = "flpanel_Function";
            this.flpanel_Function.Size = new System.Drawing.Size(460, 721);
            this.flpanel_Function.TabIndex = 20;
            this.flpanel_Function.WrapContents = false;
            // 
            // flpanel_PurchaseFuntion
            // 
            this.flpanel_PurchaseFuntion.AutoScroll = true;
            this.flpanel_PurchaseFuntion.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_PurchaseFuntion.Controls.Add(this.label8);
            this.flpanel_PurchaseFuntion.Controls.Add(this.flpanel_Purchase_ISMM);
            this.flpanel_PurchaseFuntion.Controls.Add(this.flpanel_Purchase_PMM);
            this.flpanel_PurchaseFuntion.Controls.Add(this.flpanel_Purchase_AAM);
            this.flpanel_PurchaseFuntion.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_PurchaseFuntion.Location = new System.Drawing.Point(2, 644);
            this.flpanel_PurchaseFuntion.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_PurchaseFuntion.Name = "flpanel_PurchaseFuntion";
            this.flpanel_PurchaseFuntion.Size = new System.Drawing.Size(416, 384);
            this.flpanel_PurchaseFuntion.TabIndex = 17;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label8.ForeColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(2, 0);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(407, 37);
            this.label8.TabIndex = 15;
            this.label8.Text = "Purchase Department";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // flpanel_Purchase_ISMM
            // 
            this.flpanel_Purchase_ISMM.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_Purchase_ISMM.Controls.Add(this.button_Function_PurchasingReorderRequest);
            this.flpanel_Purchase_ISMM.Controls.Add(this.button_Function_PurchasingPurchaseOrder);
            this.flpanel_Purchase_ISMM.Controls.Add(this.button_Function_PurchasingGoodsReceivedNote);
            this.flpanel_Purchase_ISMM.Controls.Add(this.button_Function_PurchasePurchaseInvoice);
            this.flpanel_Purchase_ISMM.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_Purchase_ISMM.Location = new System.Drawing.Point(2, 39);
            this.flpanel_Purchase_ISMM.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Purchase_ISMM.Name = "flpanel_Purchase_ISMM";
            this.flpanel_Purchase_ISMM.Size = new System.Drawing.Size(412, 166);
            this.flpanel_Purchase_ISMM.TabIndex = 30;
            // 
            // button_Function_PurchasingReorderRequest
            // 
            this.button_Function_PurchasingReorderRequest.AutoSize = true;
            this.button_Function_PurchasingReorderRequest.Location = new System.Drawing.Point(2, 2);
            this.button_Function_PurchasingReorderRequest.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_PurchasingReorderRequest.Name = "button_Function_PurchasingReorderRequest";
            this.button_Function_PurchasingReorderRequest.Size = new System.Drawing.Size(407, 37);
            this.button_Function_PurchasingReorderRequest.TabIndex = 27;
            this.button_Function_PurchasingReorderRequest.Text = "Re-Order Request";
            this.button_Function_PurchasingReorderRequest.UseVisualStyleBackColor = true;
            // 
            // button_Function_PurchasingPurchaseOrder
            // 
            this.button_Function_PurchasingPurchaseOrder.AutoSize = true;
            this.button_Function_PurchasingPurchaseOrder.Location = new System.Drawing.Point(2, 43);
            this.button_Function_PurchasingPurchaseOrder.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_PurchasingPurchaseOrder.Name = "button_Function_PurchasingPurchaseOrder";
            this.button_Function_PurchasingPurchaseOrder.Size = new System.Drawing.Size(407, 37);
            this.button_Function_PurchasingPurchaseOrder.TabIndex = 25;
            this.button_Function_PurchasingPurchaseOrder.Text = "Purchase Order";
            this.button_Function_PurchasingPurchaseOrder.UseVisualStyleBackColor = true;
            // 
            // button_Function_PurchasingGoodsReceivedNote
            // 
            this.button_Function_PurchasingGoodsReceivedNote.AutoSize = true;
            this.button_Function_PurchasingGoodsReceivedNote.Location = new System.Drawing.Point(2, 84);
            this.button_Function_PurchasingGoodsReceivedNote.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_PurchasingGoodsReceivedNote.Name = "button_Function_PurchasingGoodsReceivedNote";
            this.button_Function_PurchasingGoodsReceivedNote.Size = new System.Drawing.Size(407, 37);
            this.button_Function_PurchasingGoodsReceivedNote.TabIndex = 33;
            this.button_Function_PurchasingGoodsReceivedNote.Text = "Goods Received Note";
            this.button_Function_PurchasingGoodsReceivedNote.UseVisualStyleBackColor = true;
            // 
            // button_Function_PurchasePurchaseInvoice
            // 
            this.button_Function_PurchasePurchaseInvoice.AutoSize = true;
            this.button_Function_PurchasePurchaseInvoice.Location = new System.Drawing.Point(2, 125);
            this.button_Function_PurchasePurchaseInvoice.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_PurchasePurchaseInvoice.Name = "button_Function_PurchasePurchaseInvoice";
            this.button_Function_PurchasePurchaseInvoice.Size = new System.Drawing.Size(407, 37);
            this.button_Function_PurchasePurchaseInvoice.TabIndex = 33;
            this.button_Function_PurchasePurchaseInvoice.Text = "Purchase Invoice";
            this.button_Function_PurchasePurchaseInvoice.UseVisualStyleBackColor = true;
            // 
            // flpanel_Purchase_PMM
            // 
            this.flpanel_Purchase_PMM.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_Purchase_PMM.Controls.Add(this.button_Function_PurchaseItemList);
            this.flpanel_Purchase_PMM.Controls.Add(this.button_Function_PurchaseUpdateRequest);
            this.flpanel_Purchase_PMM.Controls.Add(this.button_Function_PurchaseUpdateRequestRecord);
            this.flpanel_Purchase_PMM.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_Purchase_PMM.Location = new System.Drawing.Point(2, 209);
            this.flpanel_Purchase_PMM.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Purchase_PMM.Name = "flpanel_Purchase_PMM";
            this.flpanel_Purchase_PMM.Size = new System.Drawing.Size(412, 125);
            this.flpanel_Purchase_PMM.TabIndex = 31;
            // 
            // button_Function_PurchaseItemList
            // 
            this.button_Function_PurchaseItemList.AutoSize = true;
            this.button_Function_PurchaseItemList.Location = new System.Drawing.Point(2, 2);
            this.button_Function_PurchaseItemList.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_PurchaseItemList.Name = "button_Function_PurchaseItemList";
            this.button_Function_PurchaseItemList.Size = new System.Drawing.Size(407, 37);
            this.button_Function_PurchaseItemList.TabIndex = 24;
            this.button_Function_PurchaseItemList.Text = "Item List";
            this.button_Function_PurchaseItemList.UseVisualStyleBackColor = true;
            // 
            // button_Function_PurchaseUpdateRequest
            // 
            this.button_Function_PurchaseUpdateRequest.AutoSize = true;
            this.button_Function_PurchaseUpdateRequest.Location = new System.Drawing.Point(2, 43);
            this.button_Function_PurchaseUpdateRequest.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_PurchaseUpdateRequest.Name = "button_Function_PurchaseUpdateRequest";
            this.button_Function_PurchaseUpdateRequest.Size = new System.Drawing.Size(407, 37);
            this.button_Function_PurchaseUpdateRequest.TabIndex = 27;
            this.button_Function_PurchaseUpdateRequest.Text = "Update Request";
            this.button_Function_PurchaseUpdateRequest.UseVisualStyleBackColor = true;
            // 
            // button_Function_PurchaseUpdateRequestRecord
            // 
            this.button_Function_PurchaseUpdateRequestRecord.AutoSize = true;
            this.button_Function_PurchaseUpdateRequestRecord.Location = new System.Drawing.Point(2, 84);
            this.button_Function_PurchaseUpdateRequestRecord.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_PurchaseUpdateRequestRecord.Name = "button_Function_PurchaseUpdateRequestRecord";
            this.button_Function_PurchaseUpdateRequestRecord.Size = new System.Drawing.Size(407, 37);
            this.button_Function_PurchaseUpdateRequestRecord.TabIndex = 30;
            this.button_Function_PurchaseUpdateRequestRecord.Text = "Update Request Record";
            this.button_Function_PurchaseUpdateRequestRecord.UseVisualStyleBackColor = true;
            // 
            // flpanel_Purchase_AAM
            // 
            this.flpanel_Purchase_AAM.Controls.Add(this.button_Function_PurchaseAnalysisReport);
            this.flpanel_Purchase_AAM.Location = new System.Drawing.Point(2, 338);
            this.flpanel_Purchase_AAM.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Purchase_AAM.Name = "flpanel_Purchase_AAM";
            this.flpanel_Purchase_AAM.Size = new System.Drawing.Size(412, 42);
            this.flpanel_Purchase_AAM.TabIndex = 32;
            // 
            // button_Function_PurchaseAnalysisReport
            // 
            this.button_Function_PurchaseAnalysisReport.AutoSize = true;
            this.button_Function_PurchaseAnalysisReport.Location = new System.Drawing.Point(2, 2);
            this.button_Function_PurchaseAnalysisReport.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_PurchaseAnalysisReport.Name = "button_Function_PurchaseAnalysisReport";
            this.button_Function_PurchaseAnalysisReport.Size = new System.Drawing.Size(407, 37);
            this.button_Function_PurchaseAnalysisReport.TabIndex = 29;
            this.button_Function_PurchaseAnalysisReport.Text = "AnalysisReport";
            this.button_Function_PurchaseAnalysisReport.UseVisualStyleBackColor = true;
            // 
            // flpanel_SalesFuntion
            // 
            this.flpanel_SalesFuntion.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_SalesFuntion.Controls.Add(this.label9);
            this.flpanel_SalesFuntion.Controls.Add(this.flpanel_Sales_POS);
            this.flpanel_SalesFuntion.Controls.Add(this.flpanel_Sales_RSMM);
            this.flpanel_SalesFuntion.Controls.Add(this.flpanel_Sales_PMM);
            this.flpanel_SalesFuntion.Controls.Add(this.flpanel_Sales_AAM);
            this.flpanel_SalesFuntion.Controls.Add(this.flpanel_Sales_RIM);
            this.flpanel_SalesFuntion.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_SalesFuntion.Location = new System.Drawing.Point(2, 1032);
            this.flpanel_SalesFuntion.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_SalesFuntion.Name = "flpanel_SalesFuntion";
            this.flpanel_SalesFuntion.Size = new System.Drawing.Size(416, 504);
            this.flpanel_SalesFuntion.TabIndex = 18;
            this.flpanel_SalesFuntion.WrapContents = false;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label9.ForeColor = System.Drawing.SystemColors.Control;
            this.label9.Location = new System.Drawing.Point(2, 0);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(407, 37);
            this.label9.TabIndex = 34;
            this.label9.Text = "Sales Department";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // flpanel_Sales_POS
            // 
            this.flpanel_Sales_POS.AutoSize = true;
            this.flpanel_Sales_POS.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_Sales_POS.Controls.Add(this.button_SalesPOS);
            this.flpanel_Sales_POS.Location = new System.Drawing.Point(2, 39);
            this.flpanel_Sales_POS.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Sales_POS.Name = "flpanel_Sales_POS";
            this.flpanel_Sales_POS.Size = new System.Drawing.Size(411, 31);
            this.flpanel_Sales_POS.TabIndex = 30;
            // 
            // button_SalesPOS
            // 
            this.button_SalesPOS.AutoSize = true;
            this.button_SalesPOS.Location = new System.Drawing.Point(2, 2);
            this.button_SalesPOS.Margin = new System.Windows.Forms.Padding(2);
            this.button_SalesPOS.Name = "button_SalesPOS";
            this.button_SalesPOS.Size = new System.Drawing.Size(407, 27);
            this.button_SalesPOS.TabIndex = 20;
            this.button_SalesPOS.Text = "POS";
            this.button_SalesPOS.UseVisualStyleBackColor = true;
            // 
            // flpanel_Sales_RSMM
            // 
            this.flpanel_Sales_RSMM.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_Sales_RSMM.Controls.Add(this.button_Function_SalesItemList);
            this.flpanel_Sales_RSMM.Controls.Add(this.button_Function_SalesInventoryStorckLevel);
            this.flpanel_Sales_RSMM.Controls.Add(this.button_Function_SalesStorckLevel);
            this.flpanel_Sales_RSMM.Controls.Add(this.button_Function_SalesInventoryList);
            this.flpanel_Sales_RSMM.Controls.Add(this.button_Function_SalesReRestockRequest);
            this.flpanel_Sales_RSMM.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_Sales_RSMM.Location = new System.Drawing.Point(2, 74);
            this.flpanel_Sales_RSMM.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Sales_RSMM.Name = "flpanel_Sales_RSMM";
            this.flpanel_Sales_RSMM.Size = new System.Drawing.Size(412, 208);
            this.flpanel_Sales_RSMM.TabIndex = 28;
            // 
            // button_Function_SalesItemList
            // 
            this.button_Function_SalesItemList.AutoSize = true;
            this.button_Function_SalesItemList.Location = new System.Drawing.Point(2, 2);
            this.button_Function_SalesItemList.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_SalesItemList.Name = "button_Function_SalesItemList";
            this.button_Function_SalesItemList.Size = new System.Drawing.Size(407, 37);
            this.button_Function_SalesItemList.TabIndex = 21;
            this.button_Function_SalesItemList.Text = "Item List";
            this.button_Function_SalesItemList.UseVisualStyleBackColor = true;
            // 
            // button_Function_SalesInventoryStorckLevel
            // 
            this.button_Function_SalesInventoryStorckLevel.AutoSize = true;
            this.button_Function_SalesInventoryStorckLevel.Location = new System.Drawing.Point(2, 43);
            this.button_Function_SalesInventoryStorckLevel.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_SalesInventoryStorckLevel.Name = "button_Function_SalesInventoryStorckLevel";
            this.button_Function_SalesInventoryStorckLevel.Size = new System.Drawing.Size(407, 37);
            this.button_Function_SalesInventoryStorckLevel.TabIndex = 25;
            this.button_Function_SalesInventoryStorckLevel.Text = "Inventory Storck Level";
            this.button_Function_SalesInventoryStorckLevel.UseVisualStyleBackColor = true;
            // 
            // button_Function_SalesStorckLevel
            // 
            this.button_Function_SalesStorckLevel.AutoSize = true;
            this.button_Function_SalesStorckLevel.Location = new System.Drawing.Point(2, 84);
            this.button_Function_SalesStorckLevel.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_SalesStorckLevel.Name = "button_Function_SalesStorckLevel";
            this.button_Function_SalesStorckLevel.Size = new System.Drawing.Size(407, 37);
            this.button_Function_SalesStorckLevel.TabIndex = 23;
            this.button_Function_SalesStorckLevel.Text = "Retail Stock Level";
            this.button_Function_SalesStorckLevel.UseVisualStyleBackColor = true;
            // 
            // button_Function_SalesInventoryList
            // 
            this.button_Function_SalesInventoryList.AutoSize = true;
            this.button_Function_SalesInventoryList.Location = new System.Drawing.Point(2, 125);
            this.button_Function_SalesInventoryList.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_SalesInventoryList.Name = "button_Function_SalesInventoryList";
            this.button_Function_SalesInventoryList.Size = new System.Drawing.Size(407, 37);
            this.button_Function_SalesInventoryList.TabIndex = 22;
            this.button_Function_SalesInventoryList.Text = "Inventory List";
            this.button_Function_SalesInventoryList.UseVisualStyleBackColor = true;
            // 
            // button_Function_SalesReRestockRequest
            // 
            this.button_Function_SalesReRestockRequest.AutoSize = true;
            this.button_Function_SalesReRestockRequest.Location = new System.Drawing.Point(2, 166);
            this.button_Function_SalesReRestockRequest.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_SalesReRestockRequest.Name = "button_Function_SalesReRestockRequest";
            this.button_Function_SalesReRestockRequest.Size = new System.Drawing.Size(407, 37);
            this.button_Function_SalesReRestockRequest.TabIndex = 24;
            this.button_Function_SalesReRestockRequest.Text = "Restock Request";
            this.button_Function_SalesReRestockRequest.UseVisualStyleBackColor = true;
            // 
            // flpanel_Sales_PMM
            // 
            this.flpanel_Sales_PMM.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_Sales_PMM.Controls.Add(this.button_Function_SalesItemList2);
            this.flpanel_Sales_PMM.Controls.Add(this.button_Function_SalesUpdateRequest);
            this.flpanel_Sales_PMM.Controls.Add(this.button_Function_SalesUpdateRequestRecord);
            this.flpanel_Sales_PMM.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_Sales_PMM.Location = new System.Drawing.Point(2, 286);
            this.flpanel_Sales_PMM.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Sales_PMM.Name = "flpanel_Sales_PMM";
            this.flpanel_Sales_PMM.Size = new System.Drawing.Size(412, 125);
            this.flpanel_Sales_PMM.TabIndex = 31;
            // 
            // button_Function_SalesItemList2
            // 
            this.button_Function_SalesItemList2.AutoSize = true;
            this.button_Function_SalesItemList2.Location = new System.Drawing.Point(2, 2);
            this.button_Function_SalesItemList2.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_SalesItemList2.Name = "button_Function_SalesItemList2";
            this.button_Function_SalesItemList2.Size = new System.Drawing.Size(407, 37);
            this.button_Function_SalesItemList2.TabIndex = 22;
            this.button_Function_SalesItemList2.Text = "Item List";
            this.button_Function_SalesItemList2.UseVisualStyleBackColor = true;
            // 
            // button_Function_SalesUpdateRequest
            // 
            this.button_Function_SalesUpdateRequest.AutoSize = true;
            this.button_Function_SalesUpdateRequest.Location = new System.Drawing.Point(2, 43);
            this.button_Function_SalesUpdateRequest.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_SalesUpdateRequest.Name = "button_Function_SalesUpdateRequest";
            this.button_Function_SalesUpdateRequest.Size = new System.Drawing.Size(407, 37);
            this.button_Function_SalesUpdateRequest.TabIndex = 25;
            this.button_Function_SalesUpdateRequest.Text = "Update Request";
            this.button_Function_SalesUpdateRequest.UseVisualStyleBackColor = true;
            // 
            // button_Function_SalesUpdateRequestRecord
            // 
            this.button_Function_SalesUpdateRequestRecord.AutoSize = true;
            this.button_Function_SalesUpdateRequestRecord.Location = new System.Drawing.Point(2, 84);
            this.button_Function_SalesUpdateRequestRecord.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_SalesUpdateRequestRecord.Name = "button_Function_SalesUpdateRequestRecord";
            this.button_Function_SalesUpdateRequestRecord.Size = new System.Drawing.Size(407, 37);
            this.button_Function_SalesUpdateRequestRecord.TabIndex = 28;
            this.button_Function_SalesUpdateRequestRecord.Text = "Update Request Record";
            this.button_Function_SalesUpdateRequestRecord.UseVisualStyleBackColor = true;
            // 
            // flpanel_Sales_AAM
            // 
            this.flpanel_Sales_AAM.Controls.Add(this.button_Function_SalesAnalysisReport);
            this.flpanel_Sales_AAM.Location = new System.Drawing.Point(2, 415);
            this.flpanel_Sales_AAM.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Sales_AAM.Name = "flpanel_Sales_AAM";
            this.flpanel_Sales_AAM.Size = new System.Drawing.Size(412, 42);
            this.flpanel_Sales_AAM.TabIndex = 32;
            // 
            // button_Function_SalesAnalysisReport
            // 
            this.button_Function_SalesAnalysisReport.AutoSize = true;
            this.button_Function_SalesAnalysisReport.Location = new System.Drawing.Point(2, 2);
            this.button_Function_SalesAnalysisReport.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_SalesAnalysisReport.Name = "button_Function_SalesAnalysisReport";
            this.button_Function_SalesAnalysisReport.Size = new System.Drawing.Size(407, 37);
            this.button_Function_SalesAnalysisReport.TabIndex = 31;
            this.button_Function_SalesAnalysisReport.Text = "AnalysisReport";
            this.button_Function_SalesAnalysisReport.UseVisualStyleBackColor = true;
            // 
            // flpanel_Sales_RIM
            // 
            this.flpanel_Sales_RIM.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_Sales_RIM.Controls.Add(this.button_Function_SalesGoodsReturnedRecord);
            this.flpanel_Sales_RIM.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_Sales_RIM.Location = new System.Drawing.Point(2, 461);
            this.flpanel_Sales_RIM.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Sales_RIM.Name = "flpanel_Sales_RIM";
            this.flpanel_Sales_RIM.Size = new System.Drawing.Size(412, 46);
            this.flpanel_Sales_RIM.TabIndex = 33;
            // 
            // button_Function_SalesGoodsReturnedRecord
            // 
            this.button_Function_SalesGoodsReturnedRecord.AutoSize = true;
            this.button_Function_SalesGoodsReturnedRecord.Location = new System.Drawing.Point(2, 2);
            this.button_Function_SalesGoodsReturnedRecord.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_SalesGoodsReturnedRecord.Name = "button_Function_SalesGoodsReturnedRecord";
            this.button_Function_SalesGoodsReturnedRecord.Size = new System.Drawing.Size(407, 37);
            this.button_Function_SalesGoodsReturnedRecord.TabIndex = 27;
            this.button_Function_SalesGoodsReturnedRecord.Text = "Goods Returned Record";
            this.button_Function_SalesGoodsReturnedRecord.UseVisualStyleBackColor = true;
            // 
            // flpanel_TechnicalFuntion
            // 
            this.flpanel_TechnicalFuntion.AutoSize = true;
            this.flpanel_TechnicalFuntion.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_TechnicalFuntion.Controls.Add(this.label10);
            this.flpanel_TechnicalFuntion.Controls.Add(this.flpanel_Technical_AAM);
            this.flpanel_TechnicalFuntion.Controls.Add(this.flpanel_Technical_DIM);
            this.flpanel_TechnicalFuntion.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_TechnicalFuntion.Location = new System.Drawing.Point(2, 1540);
            this.flpanel_TechnicalFuntion.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_TechnicalFuntion.Name = "flpanel_TechnicalFuntion";
            this.flpanel_TechnicalFuntion.Size = new System.Drawing.Size(415, 209);
            this.flpanel_TechnicalFuntion.TabIndex = 19;
            this.flpanel_TechnicalFuntion.WrapContents = false;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label10.ForeColor = System.Drawing.SystemColors.Control;
            this.label10.Location = new System.Drawing.Point(2, 0);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(407, 37);
            this.label10.TabIndex = 15;
            this.label10.Text = "Technical Support Department";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // flpanel_Technical_AAM
            // 
            this.flpanel_Technical_AAM.AutoSize = true;
            this.flpanel_Technical_AAM.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_Technical_AAM.Controls.Add(this.button_Function_TechnicalAnalysisReport);
            this.flpanel_Technical_AAM.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_Technical_AAM.Location = new System.Drawing.Point(2, 39);
            this.flpanel_Technical_AAM.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Technical_AAM.Name = "flpanel_Technical_AAM";
            this.flpanel_Technical_AAM.Size = new System.Drawing.Size(411, 41);
            this.flpanel_Technical_AAM.TabIndex = 33;
            // 
            // button_Function_TechnicalAnalysisReport
            // 
            this.button_Function_TechnicalAnalysisReport.AutoSize = true;
            this.button_Function_TechnicalAnalysisReport.Location = new System.Drawing.Point(2, 2);
            this.button_Function_TechnicalAnalysisReport.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_TechnicalAnalysisReport.Name = "button_Function_TechnicalAnalysisReport";
            this.button_Function_TechnicalAnalysisReport.Size = new System.Drawing.Size(407, 37);
            this.button_Function_TechnicalAnalysisReport.TabIndex = 32;
            this.button_Function_TechnicalAnalysisReport.Text = "AnalysisReport";
            this.button_Function_TechnicalAnalysisReport.UseVisualStyleBackColor = true;
            // 
            // flpanel_Technical_DIM
            // 
            this.flpanel_Technical_DIM.AutoSize = true;
            this.flpanel_Technical_DIM.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_Technical_DIM.Controls.Add(this.button_Function_TechnicalWorkmenInfoRecord);
            this.flpanel_Technical_DIM.Controls.Add(this.button_Function_TechnicalWorkmenDutyRecord);
            this.flpanel_Technical_DIM.Controls.Add(this.button_Function_TechnicalInstallationArrangement);
            this.flpanel_Technical_DIM.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_Technical_DIM.Location = new System.Drawing.Point(2, 84);
            this.flpanel_Technical_DIM.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Technical_DIM.Name = "flpanel_Technical_DIM";
            this.flpanel_Technical_DIM.Size = new System.Drawing.Size(411, 123);
            this.flpanel_Technical_DIM.TabIndex = 21;
            this.flpanel_Technical_DIM.WrapContents = false;
            // 
            // button_Function_TechnicalWorkmenInfoRecord
            // 
            this.button_Function_TechnicalWorkmenInfoRecord.AutoSize = true;
            this.button_Function_TechnicalWorkmenInfoRecord.Location = new System.Drawing.Point(2, 2);
            this.button_Function_TechnicalWorkmenInfoRecord.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_TechnicalWorkmenInfoRecord.Name = "button_Function_TechnicalWorkmenInfoRecord";
            this.button_Function_TechnicalWorkmenInfoRecord.Size = new System.Drawing.Size(407, 37);
            this.button_Function_TechnicalWorkmenInfoRecord.TabIndex = 24;
            this.button_Function_TechnicalWorkmenInfoRecord.Text = "Workmen Info Record";
            this.button_Function_TechnicalWorkmenInfoRecord.UseVisualStyleBackColor = true;
            // 
            // button_Function_TechnicalWorkmenDutyRecord
            // 
            this.button_Function_TechnicalWorkmenDutyRecord.AutoSize = true;
            this.button_Function_TechnicalWorkmenDutyRecord.Location = new System.Drawing.Point(2, 43);
            this.button_Function_TechnicalWorkmenDutyRecord.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_TechnicalWorkmenDutyRecord.Name = "button_Function_TechnicalWorkmenDutyRecord";
            this.button_Function_TechnicalWorkmenDutyRecord.Size = new System.Drawing.Size(407, 37);
            this.button_Function_TechnicalWorkmenDutyRecord.TabIndex = 26;
            this.button_Function_TechnicalWorkmenDutyRecord.Text = "Workmen Duty Record";
            this.button_Function_TechnicalWorkmenDutyRecord.UseVisualStyleBackColor = true;
            // 
            // button_Function_TechnicalInstallationArrangement
            // 
            this.button_Function_TechnicalInstallationArrangement.AccessibleRole = System.Windows.Forms.AccessibleRole.Clock;
            this.button_Function_TechnicalInstallationArrangement.AutoSize = true;
            this.button_Function_TechnicalInstallationArrangement.Location = new System.Drawing.Point(2, 84);
            this.button_Function_TechnicalInstallationArrangement.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_TechnicalInstallationArrangement.Name = "button_Function_TechnicalInstallationArrangement";
            this.button_Function_TechnicalInstallationArrangement.Size = new System.Drawing.Size(407, 37);
            this.button_Function_TechnicalInstallationArrangement.TabIndex = 28;
            this.button_Function_TechnicalInstallationArrangement.Text = "Installation Arrangement";
            this.button_Function_TechnicalInstallationArrangement.UseVisualStyleBackColor = true;
            // 
            // flpanel_InventoryFuntion
            // 
            this.flpanel_InventoryFuntion.AutoScroll = true;
            this.flpanel_InventoryFuntion.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_InventoryFuntion.Controls.Add(this.label11);
            this.flpanel_InventoryFuntion.Controls.Add(this.flpanel_Inventory_DIM);
            this.flpanel_InventoryFuntion.Controls.Add(this.flpanel_Inventory_AAM);
            this.flpanel_InventoryFuntion.Controls.Add(this.flpanel_Inventory_RIM);
            this.flpanel_InventoryFuntion.Controls.Add(this.flpanel_Inventory_ISMM);
            this.flpanel_InventoryFuntion.Controls.Add(this.flpanel_Inventory_RSMM);
            this.flpanel_InventoryFuntion.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_InventoryFuntion.Location = new System.Drawing.Point(2, 1753);
            this.flpanel_InventoryFuntion.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_InventoryFuntion.Name = "flpanel_InventoryFuntion";
            this.flpanel_InventoryFuntion.Size = new System.Drawing.Size(416, 479);
            this.flpanel_InventoryFuntion.TabIndex = 21;
            this.flpanel_InventoryFuntion.WrapContents = false;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label11.ForeColor = System.Drawing.SystemColors.Control;
            this.label11.Location = new System.Drawing.Point(2, 0);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(412, 37);
            this.label11.TabIndex = 15;
            this.label11.Text = "Inventory Department";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // flpanel_Inventory_DIM
            // 
            this.flpanel_Inventory_DIM.AutoSize = true;
            this.flpanel_Inventory_DIM.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_Inventory_DIM.Controls.Add(this.button_Function_InventoryWorkmenInfoRecord);
            this.flpanel_Inventory_DIM.Controls.Add(this.button_Function_InventoryWorkmenDutyRecord);
            this.flpanel_Inventory_DIM.Controls.Add(this.button_Function_InventoryDeliveryArrangement);
            this.flpanel_Inventory_DIM.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_Inventory_DIM.Location = new System.Drawing.Point(2, 39);
            this.flpanel_Inventory_DIM.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Inventory_DIM.Name = "flpanel_Inventory_DIM";
            this.flpanel_Inventory_DIM.Size = new System.Drawing.Size(411, 123);
            this.flpanel_Inventory_DIM.TabIndex = 20;
            // 
            // button_Function_InventoryWorkmenInfoRecord
            // 
            this.button_Function_InventoryWorkmenInfoRecord.AutoSize = true;
            this.button_Function_InventoryWorkmenInfoRecord.Location = new System.Drawing.Point(2, 2);
            this.button_Function_InventoryWorkmenInfoRecord.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_InventoryWorkmenInfoRecord.Name = "button_Function_InventoryWorkmenInfoRecord";
            this.button_Function_InventoryWorkmenInfoRecord.Size = new System.Drawing.Size(407, 37);
            this.button_Function_InventoryWorkmenInfoRecord.TabIndex = 23;
            this.button_Function_InventoryWorkmenInfoRecord.Text = "Workmen Info Record";
            this.button_Function_InventoryWorkmenInfoRecord.UseVisualStyleBackColor = true;
            // 
            // button_Function_InventoryWorkmenDutyRecord
            // 
            this.button_Function_InventoryWorkmenDutyRecord.AutoSize = true;
            this.button_Function_InventoryWorkmenDutyRecord.Location = new System.Drawing.Point(2, 43);
            this.button_Function_InventoryWorkmenDutyRecord.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_InventoryWorkmenDutyRecord.Name = "button_Function_InventoryWorkmenDutyRecord";
            this.button_Function_InventoryWorkmenDutyRecord.Size = new System.Drawing.Size(407, 37);
            this.button_Function_InventoryWorkmenDutyRecord.TabIndex = 25;
            this.button_Function_InventoryWorkmenDutyRecord.Text = "Workmen Duty Record";
            this.button_Function_InventoryWorkmenDutyRecord.UseVisualStyleBackColor = true;
            // 
            // button_Function_InventoryDeliveryArrangement
            // 
            this.button_Function_InventoryDeliveryArrangement.AccessibleRole = System.Windows.Forms.AccessibleRole.Clock;
            this.button_Function_InventoryDeliveryArrangement.AutoSize = true;
            this.button_Function_InventoryDeliveryArrangement.Location = new System.Drawing.Point(2, 84);
            this.button_Function_InventoryDeliveryArrangement.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_InventoryDeliveryArrangement.Name = "button_Function_InventoryDeliveryArrangement";
            this.button_Function_InventoryDeliveryArrangement.Size = new System.Drawing.Size(407, 37);
            this.button_Function_InventoryDeliveryArrangement.TabIndex = 27;
            this.button_Function_InventoryDeliveryArrangement.Text = "Delivery Arrangement";
            this.button_Function_InventoryDeliveryArrangement.UseVisualStyleBackColor = true;
            // 
            // flpanel_Inventory_AAM
            // 
            this.flpanel_Inventory_AAM.AutoSize = true;
            this.flpanel_Inventory_AAM.Controls.Add(this.button_Function_InventoryAnalysisReport);
            this.flpanel_Inventory_AAM.Location = new System.Drawing.Point(2, 166);
            this.flpanel_Inventory_AAM.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Inventory_AAM.Name = "flpanel_Inventory_AAM";
            this.flpanel_Inventory_AAM.Size = new System.Drawing.Size(411, 41);
            this.flpanel_Inventory_AAM.TabIndex = 24;
            // 
            // button_Function_InventoryAnalysisReport
            // 
            this.button_Function_InventoryAnalysisReport.AutoSize = true;
            this.button_Function_InventoryAnalysisReport.Location = new System.Drawing.Point(2, 2);
            this.button_Function_InventoryAnalysisReport.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_InventoryAnalysisReport.Name = "button_Function_InventoryAnalysisReport";
            this.button_Function_InventoryAnalysisReport.Size = new System.Drawing.Size(407, 37);
            this.button_Function_InventoryAnalysisReport.TabIndex = 30;
            this.button_Function_InventoryAnalysisReport.Text = "AnalysisReport";
            this.button_Function_InventoryAnalysisReport.UseVisualStyleBackColor = true;
            // 
            // flpanel_Inventory_RIM
            // 
            this.flpanel_Inventory_RIM.AutoSize = true;
            this.flpanel_Inventory_RIM.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_Inventory_RIM.Controls.Add(this.button_Function_InventoryGoodsReturnedRecord);
            this.flpanel_Inventory_RIM.Location = new System.Drawing.Point(2, 211);
            this.flpanel_Inventory_RIM.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Inventory_RIM.Name = "flpanel_Inventory_RIM";
            this.flpanel_Inventory_RIM.Size = new System.Drawing.Size(411, 41);
            this.flpanel_Inventory_RIM.TabIndex = 29;
            // 
            // button_Function_InventoryGoodsReturnedRecord
            // 
            this.button_Function_InventoryGoodsReturnedRecord.AutoSize = true;
            this.button_Function_InventoryGoodsReturnedRecord.Location = new System.Drawing.Point(2, 2);
            this.button_Function_InventoryGoodsReturnedRecord.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_InventoryGoodsReturnedRecord.Name = "button_Function_InventoryGoodsReturnedRecord";
            this.button_Function_InventoryGoodsReturnedRecord.Size = new System.Drawing.Size(407, 37);
            this.button_Function_InventoryGoodsReturnedRecord.TabIndex = 27;
            this.button_Function_InventoryGoodsReturnedRecord.Text = "Goods Returned Record";
            this.button_Function_InventoryGoodsReturnedRecord.UseVisualStyleBackColor = true;
            // 
            // flpanel_Inventory_ISMM
            // 
            this.flpanel_Inventory_ISMM.AutoSize = true;
            this.flpanel_Inventory_ISMM.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_Inventory_ISMM.Controls.Add(this.button_Function_InventoryInventoryStorckLevel);
            this.flpanel_Inventory_ISMM.Controls.Add(this.button_Function_InventoryReorderRequest);
            this.flpanel_Inventory_ISMM.Controls.Add(this.button_Function_InventoryPurchaseOrder);
            this.flpanel_Inventory_ISMM.Controls.Add(this.button_Function_InventoryGoodsReceivedNote);
            this.flpanel_Inventory_ISMM.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpanel_Inventory_ISMM.Location = new System.Drawing.Point(2, 256);
            this.flpanel_Inventory_ISMM.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Inventory_ISMM.Name = "flpanel_Inventory_ISMM";
            this.flpanel_Inventory_ISMM.Size = new System.Drawing.Size(411, 164);
            this.flpanel_Inventory_ISMM.TabIndex = 30;
            // 
            // button_Function_InventoryInventoryStorckLevel
            // 
            this.button_Function_InventoryInventoryStorckLevel.AutoSize = true;
            this.button_Function_InventoryInventoryStorckLevel.Location = new System.Drawing.Point(2, 2);
            this.button_Function_InventoryInventoryStorckLevel.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_InventoryInventoryStorckLevel.Name = "button_Function_InventoryInventoryStorckLevel";
            this.button_Function_InventoryInventoryStorckLevel.Size = new System.Drawing.Size(407, 37);
            this.button_Function_InventoryInventoryStorckLevel.TabIndex = 24;
            this.button_Function_InventoryInventoryStorckLevel.Text = "Inventory Storck Level";
            this.button_Function_InventoryInventoryStorckLevel.UseVisualStyleBackColor = true;
            // 
            // button_Function_InventoryReorderRequest
            // 
            this.button_Function_InventoryReorderRequest.AutoSize = true;
            this.button_Function_InventoryReorderRequest.Location = new System.Drawing.Point(2, 43);
            this.button_Function_InventoryReorderRequest.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_InventoryReorderRequest.Name = "button_Function_InventoryReorderRequest";
            this.button_Function_InventoryReorderRequest.Size = new System.Drawing.Size(407, 37);
            this.button_Function_InventoryReorderRequest.TabIndex = 23;
            this.button_Function_InventoryReorderRequest.Text = "Re-Order Request";
            this.button_Function_InventoryReorderRequest.UseVisualStyleBackColor = true;
            // 
            // button_Function_InventoryPurchaseOrder
            // 
            this.button_Function_InventoryPurchaseOrder.AutoSize = true;
            this.button_Function_InventoryPurchaseOrder.Location = new System.Drawing.Point(2, 84);
            this.button_Function_InventoryPurchaseOrder.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_InventoryPurchaseOrder.Name = "button_Function_InventoryPurchaseOrder";
            this.button_Function_InventoryPurchaseOrder.Size = new System.Drawing.Size(407, 37);
            this.button_Function_InventoryPurchaseOrder.TabIndex = 33;
            this.button_Function_InventoryPurchaseOrder.Text = "Purchase Order";
            this.button_Function_InventoryPurchaseOrder.UseVisualStyleBackColor = true;
            // 
            // button_Function_InventoryGoodsReceivedNote
            // 
            this.button_Function_InventoryGoodsReceivedNote.AutoSize = true;
            this.button_Function_InventoryGoodsReceivedNote.Location = new System.Drawing.Point(2, 125);
            this.button_Function_InventoryGoodsReceivedNote.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_InventoryGoodsReceivedNote.Name = "button_Function_InventoryGoodsReceivedNote";
            this.button_Function_InventoryGoodsReceivedNote.Size = new System.Drawing.Size(407, 37);
            this.button_Function_InventoryGoodsReceivedNote.TabIndex = 24;
            this.button_Function_InventoryGoodsReceivedNote.Text = "Goods Received Note";
            this.button_Function_InventoryGoodsReceivedNote.UseVisualStyleBackColor = true;
            // 
            // flpanel_Inventory_RSMM
            // 
            this.flpanel_Inventory_RSMM.AutoSize = true;
            this.flpanel_Inventory_RSMM.BackColor = System.Drawing.Color.Transparent;
            this.flpanel_Inventory_RSMM.Controls.Add(this.button_Function_InventoryInventoryStorckLevel2);
            this.flpanel_Inventory_RSMM.Location = new System.Drawing.Point(2, 424);
            this.flpanel_Inventory_RSMM.Margin = new System.Windows.Forms.Padding(2);
            this.flpanel_Inventory_RSMM.Name = "flpanel_Inventory_RSMM";
            this.flpanel_Inventory_RSMM.Size = new System.Drawing.Size(411, 41);
            this.flpanel_Inventory_RSMM.TabIndex = 32;
            // 
            // button_Function_InventoryInventoryStorckLevel2
            // 
            this.button_Function_InventoryInventoryStorckLevel2.AutoSize = true;
            this.button_Function_InventoryInventoryStorckLevel2.Location = new System.Drawing.Point(2, 2);
            this.button_Function_InventoryInventoryStorckLevel2.Margin = new System.Windows.Forms.Padding(2);
            this.button_Function_InventoryInventoryStorckLevel2.Name = "button_Function_InventoryInventoryStorckLevel2";
            this.button_Function_InventoryInventoryStorckLevel2.Size = new System.Drawing.Size(407, 37);
            this.button_Function_InventoryInventoryStorckLevel2.TabIndex = 25;
            this.button_Function_InventoryInventoryStorckLevel2.Text = "Inventory Storck Level";
            this.button_Function_InventoryInventoryStorckLevel2.UseVisualStyleBackColor = true;
            // 
            // lblStaffID
            // 
            this.lblStaffID.AutoSize = true;
            this.lblStaffID.Location = new System.Drawing.Point(127, 161);
            this.lblStaffID.Name = "lblStaffID";
            this.lblStaffID.Size = new System.Drawing.Size(33, 12);
            this.lblStaffID.TabIndex = 21;
            this.lblStaffID.Text = "label2";
            // 
            // MenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1332, 849);
            this.Controls.Add(this.lblStaffID);
            this.Controls.Add(this.flpanel_Function);
            this.Controls.Add(this.Bar_2);
            this.Controls.Add(this.Lable_Munebar);
            this.Controls.Add(this.button_Language);
            this.Controls.Add(this.button_LogOut);
            this.Controls.Add(this.button_AccountSetting);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Label_UserDepartment);
            this.Controls.Add(this.Label_UserPosition);
            this.Controls.Add(this.Label_UserName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Bar_1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "MenuForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mune";
            this.Load += new System.EventHandler(this.Mune_Load);
            this.Lable_Munebar.ResumeLayout(false);
            this.Lable_Munebar.PerformLayout();
            this.flPanel_AccountDepart.ResumeLayout(false);
            this.flPanel_PurchaseDepart.ResumeLayout(false);
            this.flPanel_SalesDepart.ResumeLayout(false);
            this.flPanel_TechnicalDepart.ResumeLayout(false);
            this.flPanel_InventoryDepart.ResumeLayout(false);
            this.flpanel_AccountFuntion.ResumeLayout(false);
            this.flpanel_AccountFuntion.PerformLayout();
            this.flpanel_Account_ISMM.ResumeLayout(false);
            this.flpanel_Account_ISMM.PerformLayout();
            this.flpanel_Account_PMM.ResumeLayout(false);
            this.flpanel_Account_PMM.PerformLayout();
            this.flpanel_Account_AAM.ResumeLayout(false);
            this.flpanel_Account_AAM.PerformLayout();
            this.flpanel_Account_RIM.ResumeLayout(false);
            this.flpanel_Account_RIM.PerformLayout();
            this.flpanel_Function.ResumeLayout(false);
            this.flpanel_Function.PerformLayout();
            this.flpanel_PurchaseFuntion.ResumeLayout(false);
            this.flpanel_Purchase_ISMM.ResumeLayout(false);
            this.flpanel_Purchase_ISMM.PerformLayout();
            this.flpanel_Purchase_PMM.ResumeLayout(false);
            this.flpanel_Purchase_PMM.PerformLayout();
            this.flpanel_Purchase_AAM.ResumeLayout(false);
            this.flpanel_Purchase_AAM.PerformLayout();
            this.flpanel_SalesFuntion.ResumeLayout(false);
            this.flpanel_SalesFuntion.PerformLayout();
            this.flpanel_Sales_POS.ResumeLayout(false);
            this.flpanel_Sales_POS.PerformLayout();
            this.flpanel_Sales_RSMM.ResumeLayout(false);
            this.flpanel_Sales_RSMM.PerformLayout();
            this.flpanel_Sales_PMM.ResumeLayout(false);
            this.flpanel_Sales_PMM.PerformLayout();
            this.flpanel_Sales_AAM.ResumeLayout(false);
            this.flpanel_Sales_AAM.PerformLayout();
            this.flpanel_Sales_RIM.ResumeLayout(false);
            this.flpanel_Sales_RIM.PerformLayout();
            this.flpanel_TechnicalFuntion.ResumeLayout(false);
            this.flpanel_TechnicalFuntion.PerformLayout();
            this.flpanel_Technical_AAM.ResumeLayout(false);
            this.flpanel_Technical_AAM.PerformLayout();
            this.flpanel_Technical_DIM.ResumeLayout(false);
            this.flpanel_Technical_DIM.PerformLayout();
            this.flpanel_InventoryFuntion.ResumeLayout(false);
            this.flpanel_InventoryFuntion.PerformLayout();
            this.flpanel_Inventory_DIM.ResumeLayout(false);
            this.flpanel_Inventory_DIM.PerformLayout();
            this.flpanel_Inventory_AAM.ResumeLayout(false);
            this.flpanel_Inventory_AAM.PerformLayout();
            this.flpanel_Inventory_RIM.ResumeLayout(false);
            this.flpanel_Inventory_RIM.PerformLayout();
            this.flpanel_Inventory_ISMM.ResumeLayout(false);
            this.flpanel_Inventory_ISMM.PerformLayout();
            this.flpanel_Inventory_RSMM.ResumeLayout(false);
            this.flpanel_Inventory_RSMM.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Bar_2;
        private System.Windows.Forms.Label Bar_1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Label_UserName;
        private System.Windows.Forms.Label Label_UserPosition;
        private System.Windows.Forms.Label Label_UserDepartment;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_AccountSetting;
        private System.Windows.Forms.Button button_LogOut;
        private System.Windows.Forms.Button button_Language;
        private System.Windows.Forms.Button button_POSModule_Sales;
        private System.Windows.Forms.Button button_RetailStorckManageModule_Sales;
        private System.Windows.Forms.Button button_RetailStorckManageModule_Inventory;
        private System.Windows.Forms.Button button_InventoryStorckMangementModule_Inventory;
        private System.Windows.Forms.Button button_InventoryStorckMangementModul_Account;
        private System.Windows.Forms.Button button_InventoryStorckMangementModule_Purchase;
        private System.Windows.Forms.Button button_DeliveryInstallationModule_Inventory;
        private System.Windows.Forms.Button button_DeliverAndInstallModule_Technical;
        private System.Windows.Forms.Button button_ProductManageModule_Sales;
        private System.Windows.Forms.Button button_ProductManageModule_Accounting;
        private System.Windows.Forms.Button button_ProductManageModule_Purchase;
        private System.Windows.Forms.Button button_AccountingAnalysisModule_Technical;
        private System.Windows.Forms.Button button_AccountingAnalysisModule_Sales;
        private System.Windows.Forms.Button button_AccountingAnalysisModule_Inventory;
        private System.Windows.Forms.Button button_AccountingAnalysisModule_Purchase;
        private System.Windows.Forms.Button button_AccountingAnalysisModule_Accounting;
        private System.Windows.Forms.Button button_SalesDepart;
        private System.Windows.Forms.Button button_PurchaseDepart;
        private System.Windows.Forms.Button button_AccountingDepart;
        private System.Windows.Forms.Button button_InventoryDepart;
        private System.Windows.Forms.Button button_TechnicalDepart;
        private System.Windows.Forms.FlowLayoutPanel flpanel_AccountFuntion;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Account_ISMM;
        private System.Windows.Forms.Button button_Function_AccountGoodsReceivedNote;
        private System.Windows.Forms.Button button_Function_AccountPurchaseInvoice;
        private System.Windows.Forms.Button button_Function_AccountPurchaseOrder;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Account_PMM;
        private System.Windows.Forms.Button button_Function_AccountItemList;
        private System.Windows.Forms.Button button_Function_AccountUpdateRequest;
        private System.Windows.Forms.Button button_Function_AccountUpdateRequestRecord;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Account_AAM;
        private System.Windows.Forms.Button button_Function_AccountAnalysisReport;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button_Function_AccountItemList2;
        private System.Windows.Forms.Button button_Function_AccountPurchaseOrder2;
        private System.Windows.Forms.Button button_Function_AccountGoodsReceivedNote2;
        private System.Windows.Forms.Button button_Function_AccountPurchaseInvoice2;
        private System.Windows.Forms.Button button_Function_AccountGoodsReturnedNote;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Account_RIM;
        private System.Windows.Forms.Button button_Function_AccountGoodsReturnedRecord;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Function;
        private System.Windows.Forms.FlowLayoutPanel flpanel_PurchaseFuntion;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Purchase_ISMM;
        private System.Windows.Forms.Button button_Function_PurchasingReorderRequest;
        private System.Windows.Forms.Button button_Function_PurchasingPurchaseOrder;
        private System.Windows.Forms.Button button_Function_PurchasingGoodsReceivedNote;
        private System.Windows.Forms.Button button_Function_PurchasePurchaseInvoice;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Purchase_PMM;
        private System.Windows.Forms.Button button_Function_PurchaseItemList;
        private System.Windows.Forms.Button button_Function_PurchaseUpdateRequest;
        private System.Windows.Forms.Button button_Function_PurchaseUpdateRequestRecord;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Purchase_AAM;
        private System.Windows.Forms.Button button_Function_PurchaseAnalysisReport;
        private System.Windows.Forms.FlowLayoutPanel flpanel_SalesFuntion;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Sales_POS;
        private System.Windows.Forms.Button button_SalesPOS;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Sales_RSMM;
        private System.Windows.Forms.Button button_Function_SalesItemList;
        private System.Windows.Forms.Button button_Function_SalesInventoryStorckLevel;
        private System.Windows.Forms.Button button_Function_SalesStorckLevel;
        private System.Windows.Forms.Button button_Function_SalesInventoryList;
        private System.Windows.Forms.Button button_Function_SalesReRestockRequest;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Sales_PMM;
        private System.Windows.Forms.Button button_Function_SalesItemList2;
        private System.Windows.Forms.Button button_Function_SalesUpdateRequest;
        private System.Windows.Forms.Button button_Function_SalesUpdateRequestRecord;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Sales_AAM;
        private System.Windows.Forms.Button button_Function_SalesAnalysisReport;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Sales_RIM;
        private System.Windows.Forms.Button button_Function_SalesGoodsReturnedRecord;
        private System.Windows.Forms.FlowLayoutPanel flpanel_TechnicalFuntion;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Technical_DIM;
        private System.Windows.Forms.Button button_Function_TechnicalWorkmenInfoRecord;
        private System.Windows.Forms.Button button_Function_TechnicalWorkmenDutyRecord;
        private System.Windows.Forms.Button button_Function_TechnicalInstallationArrangement;
        private System.Windows.Forms.FlowLayoutPanel flPanel_SalesDepart;
        private System.Windows.Forms.FlowLayoutPanel flPanel_AccountDepart;
        private System.Windows.Forms.FlowLayoutPanel flPanel_PurchaseDepart;
        private System.Windows.Forms.FlowLayoutPanel flPanel_TechnicalDepart;
        private System.Windows.Forms.FlowLayoutPanel flPanel_InventoryDepart;
        private System.Windows.Forms.FlowLayoutPanel Lable_Munebar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button_ReturnItemsModule_Sales;
        private System.Windows.Forms.Button button_ReturnItemModule_Inventory;
        private System.Windows.Forms.FlowLayoutPanel flpanel_InventoryFuntion;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Inventory_DIM;
        private System.Windows.Forms.Button button_Function_InventoryWorkmenInfoRecord;
        private System.Windows.Forms.Button button_Function_InventoryWorkmenDutyRecord;
        private System.Windows.Forms.Button button_Function_InventoryDeliveryArrangement;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Inventory_AAM;
        private System.Windows.Forms.Button button_Function_InventoryAnalysisReport;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Inventory_RIM;
        private System.Windows.Forms.Button button_Function_InventoryGoodsReturnedRecord;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Inventory_ISMM;
        private System.Windows.Forms.Button button_Function_InventoryInventoryStorckLevel;
        private System.Windows.Forms.Button button_Function_InventoryReorderRequest;
        private System.Windows.Forms.Button button_Function_InventoryPurchaseOrder;
        private System.Windows.Forms.Button button_Function_InventoryGoodsReceivedNote;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Inventory_RSMM;
        private System.Windows.Forms.Button button_Function_InventoryInventoryStorckLevel2;
        private System.Windows.Forms.FlowLayoutPanel flpanel_Technical_AAM;
        private System.Windows.Forms.Button button_Function_TechnicalAnalysisReport;
        private System.Windows.Forms.Label lblStaffID;
    }
}

