﻿namespace BetterLimited
{
    partial class UpdateUserAccountForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_Email = new System.Windows.Forms.Label();
            this.label_StaffID = new System.Windows.Forms.Label();
            this.label_UserName = new System.Windows.Forms.Label();
            this.label_UserAccountID = new System.Windows.Forms.Label();
            this.textBox_UserAccountID = new System.Windows.Forms.TextBox();
            this.textBox_Email = new System.Windows.Forms.TextBox();
            this.textbox_StaffID = new System.Windows.Forms.TextBox();
            this.textBox_UserName = new System.Windows.Forms.TextBox();
            this.button_cacel = new System.Windows.Forms.Button();
            this.button_Update = new System.Windows.Forms.Button();
            this.comboBox_Depart = new System.Windows.Forms.ComboBox();
            this.comboBox_Position = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(34, 29);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(405, 35);
            this.label2.TabIndex = 5;
            this.label2.Text = "Update Account Management";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(502, 85);
            this.panel1.TabIndex = 1;
            // 
            // label_Email
            // 
            this.label_Email.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Email.Location = new System.Drawing.Point(59, 253);
            this.label_Email.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Email.Name = "label_Email";
            this.label_Email.Size = new System.Drawing.Size(121, 20);
            this.label_Email.TabIndex = 27;
            this.label_Email.Text = "Email :";
            // 
            // label_StaffID
            // 
            this.label_StaffID.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_StaffID.Location = new System.Drawing.Point(59, 170);
            this.label_StaffID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_StaffID.Name = "label_StaffID";
            this.label_StaffID.Size = new System.Drawing.Size(121, 20);
            this.label_StaffID.TabIndex = 25;
            this.label_StaffID.Text = "StaffID :";
            // 
            // label_UserName
            // 
            this.label_UserName.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_UserName.Location = new System.Drawing.Point(59, 214);
            this.label_UserName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_UserName.Name = "label_UserName";
            this.label_UserName.Size = new System.Drawing.Size(121, 20);
            this.label_UserName.TabIndex = 24;
            this.label_UserName.Text = "UserName  :";
            // 
            // label_UserAccountID
            // 
            this.label_UserAccountID.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_UserAccountID.Location = new System.Drawing.Point(59, 129);
            this.label_UserAccountID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_UserAccountID.Name = "label_UserAccountID";
            this.label_UserAccountID.Size = new System.Drawing.Size(121, 20);
            this.label_UserAccountID.TabIndex = 23;
            this.label_UserAccountID.Text = "UserAccountID :";
            // 
            // textBox_UserAccountID
            // 
            this.textBox_UserAccountID.Location = new System.Drawing.Point(197, 129);
            this.textBox_UserAccountID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox_UserAccountID.Name = "textBox_UserAccountID";
            this.textBox_UserAccountID.ReadOnly = true;
            this.textBox_UserAccountID.Size = new System.Drawing.Size(216, 22);
            this.textBox_UserAccountID.TabIndex = 22;
            // 
            // textBox_Email
            // 
            this.textBox_Email.Location = new System.Drawing.Point(197, 255);
            this.textBox_Email.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox_Email.Name = "textBox_Email";
            this.textBox_Email.Size = new System.Drawing.Size(216, 22);
            this.textBox_Email.TabIndex = 21;
            // 
            // textbox_StaffID
            // 
            this.textbox_StaffID.Location = new System.Drawing.Point(197, 173);
            this.textbox_StaffID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textbox_StaffID.Name = "textbox_StaffID";
            this.textbox_StaffID.ReadOnly = true;
            this.textbox_StaffID.Size = new System.Drawing.Size(216, 22);
            this.textbox_StaffID.TabIndex = 19;
            // 
            // textBox_UserName
            // 
            this.textBox_UserName.Location = new System.Drawing.Point(197, 217);
            this.textBox_UserName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox_UserName.Name = "textBox_UserName";
            this.textBox_UserName.Size = new System.Drawing.Size(216, 22);
            this.textBox_UserName.TabIndex = 18;
            // 
            // button_cacel
            // 
            this.button_cacel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button_cacel.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_cacel.Location = new System.Drawing.Point(62, 468);
            this.button_cacel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_cacel.Name = "button_cacel";
            this.button_cacel.Size = new System.Drawing.Size(139, 30);
            this.button_cacel.TabIndex = 29;
            this.button_cacel.Text = "cancel";
            this.button_cacel.UseVisualStyleBackColor = false;
            this.button_cacel.Click += new System.EventHandler(this.button_cacel_Click);
            // 
            // button_Update
            // 
            this.button_Update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button_Update.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Update.Location = new System.Drawing.Point(274, 468);
            this.button_Update.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_Update.Name = "button_Update";
            this.button_Update.Size = new System.Drawing.Size(139, 30);
            this.button_Update.TabIndex = 28;
            this.button_Update.Text = "Update";
            this.button_Update.UseVisualStyleBackColor = false;
            this.button_Update.Click += new System.EventHandler(this.button_Update_Click);
            // 
            // comboBox_Depart
            // 
            this.comboBox_Depart.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Depart.FormattingEnabled = true;
            this.comboBox_Depart.Items.AddRange(new object[] {
            "CEO",
            "Admin",
            "Accounting",
            "Inventory",
            "Purchase",
            "Sales",
            "Technical Support"});
            this.comboBox_Depart.Location = new System.Drawing.Point(197, 294);
            this.comboBox_Depart.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBox_Depart.Name = "comboBox_Depart";
            this.comboBox_Depart.Size = new System.Drawing.Size(216, 20);
            this.comboBox_Depart.TabIndex = 30;
            // 
            // comboBox_Position
            // 
            this.comboBox_Position.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Position.FormattingEnabled = true;
            this.comboBox_Position.Items.AddRange(new object[] {
            "Admin",
            "CEO",
            "Accounting Clerk",
            "Accounting Manager",
            "Delivery Workman",
            "Goods Inwards Clerk",
            "Inventory Clerk",
            "Inventory Manager",
            "Purchase Officer",
            "Sales Manager",
            "Sales Representative",
            "Installation Workman"});
            this.comboBox_Position.Location = new System.Drawing.Point(197, 328);
            this.comboBox_Position.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBox_Position.Name = "comboBox_Position";
            this.comboBox_Position.Size = new System.Drawing.Size(216, 20);
            this.comboBox_Position.TabIndex = 31;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(59, 291);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 20);
            this.label1.TabIndex = 32;
            this.label1.Text = "Depart :";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(59, 326);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 20);
            this.label3.TabIndex = 33;
            this.label3.Text = "Position :";
            // 
            // UpdateUserAccountForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(502, 619);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox_Position);
            this.Controls.Add(this.comboBox_Depart);
            this.Controls.Add(this.button_cacel);
            this.Controls.Add(this.button_Update);
            this.Controls.Add(this.label_Email);
            this.Controls.Add(this.label_StaffID);
            this.Controls.Add(this.label_UserName);
            this.Controls.Add(this.label_UserAccountID);
            this.Controls.Add(this.textBox_UserAccountID);
            this.Controls.Add(this.textBox_Email);
            this.Controls.Add(this.textbox_StaffID);
            this.Controls.Add(this.textBox_UserName);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "UpdateUserAccountForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UpdateUserAccountForm";
            this.Load += new System.EventHandler(this.UpdateUserAccountForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label_Email;
        private System.Windows.Forms.Label label_StaffID;
        private System.Windows.Forms.Label label_UserName;
        private System.Windows.Forms.Label label_UserAccountID;
        private System.Windows.Forms.TextBox textBox_UserAccountID;
        private System.Windows.Forms.TextBox textBox_Email;
        private System.Windows.Forms.TextBox textbox_StaffID;
        private System.Windows.Forms.TextBox textBox_UserName;
        private System.Windows.Forms.Button button_cacel;
        private System.Windows.Forms.Button button_Update;
        private System.Windows.Forms.ComboBox comboBox_Depart;
        private System.Windows.Forms.ComboBox comboBox_Position;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
    }
}