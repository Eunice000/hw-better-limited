﻿namespace BetterLimited
{
    partial class UpdateDeliveryStatus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_DeliveryStatus = new System.Windows.Forms.Label();
            this.comboBox_DeliveryStatus = new System.Windows.Forms.ComboBox();
            this.label_DeliveryID = new System.Windows.Forms.Label();
            this.textBox_DeliveryID = new System.Windows.Forms.TextBox();
            this.button_cacel = new System.Windows.Forms.Button();
            this.button_Update = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(26, 19);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(379, 43);
            this.label2.TabIndex = 23;
            this.label2.Text = "Update Delivery Status";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(544, 73);
            this.panel1.TabIndex = 24;
            // 
            // label_DeliveryStatus
            // 
            this.label_DeliveryStatus.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DeliveryStatus.Location = new System.Drawing.Point(43, 142);
            this.label_DeliveryStatus.Name = "label_DeliveryStatus";
            this.label_DeliveryStatus.Size = new System.Drawing.Size(185, 25);
            this.label_DeliveryStatus.TabIndex = 55;
            this.label_DeliveryStatus.Text = "Delivery Status :";
            // 
            // comboBox_DeliveryStatus
            // 
            this.comboBox_DeliveryStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_DeliveryStatus.FormattingEnabled = true;
            this.comboBox_DeliveryStatus.Items.AddRange(new object[] {
            "pending",
            "In-transit",
            "delivered"});
            this.comboBox_DeliveryStatus.Location = new System.Drawing.Point(265, 145);
            this.comboBox_DeliveryStatus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox_DeliveryStatus.Name = "comboBox_DeliveryStatus";
            this.comboBox_DeliveryStatus.Size = new System.Drawing.Size(185, 23);
            this.comboBox_DeliveryStatus.TabIndex = 54;
            // 
            // label_DeliveryID
            // 
            this.label_DeliveryID.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DeliveryID.Location = new System.Drawing.Point(81, 97);
            this.label_DeliveryID.Name = "label_DeliveryID";
            this.label_DeliveryID.Size = new System.Drawing.Size(161, 25);
            this.label_DeliveryID.TabIndex = 57;
            this.label_DeliveryID.Text = "DeliveryID :";
            // 
            // textBox_DeliveryID
            // 
            this.textBox_DeliveryID.Enabled = false;
            this.textBox_DeliveryID.Location = new System.Drawing.Point(265, 97);
            this.textBox_DeliveryID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_DeliveryID.Name = "textBox_DeliveryID";
            this.textBox_DeliveryID.Size = new System.Drawing.Size(185, 25);
            this.textBox_DeliveryID.TabIndex = 56;
            // 
            // button_cacel
            // 
            this.button_cacel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button_cacel.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_cacel.Location = new System.Drawing.Point(57, 191);
            this.button_cacel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_cacel.Name = "button_cacel";
            this.button_cacel.Size = new System.Drawing.Size(185, 38);
            this.button_cacel.TabIndex = 59;
            this.button_cacel.Text = "cancel";
            this.button_cacel.UseVisualStyleBackColor = false;
            this.button_cacel.Click += new System.EventHandler(this.button_cacel_Click);
            // 
            // button_Update
            // 
            this.button_Update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button_Update.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Update.Location = new System.Drawing.Point(265, 191);
            this.button_Update.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Update.Name = "button_Update";
            this.button_Update.Size = new System.Drawing.Size(185, 38);
            this.button_Update.TabIndex = 58;
            this.button_Update.Text = "Update";
            this.button_Update.UseVisualStyleBackColor = false;
            this.button_Update.Click += new System.EventHandler(this.button_Update_Click);
            // 
            // UpdateDeliveryStatus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(544, 278);
            this.Controls.Add(this.button_cacel);
            this.Controls.Add(this.button_Update);
            this.Controls.Add(this.label_DeliveryID);
            this.Controls.Add(this.textBox_DeliveryID);
            this.Controls.Add(this.label_DeliveryStatus);
            this.Controls.Add(this.comboBox_DeliveryStatus);
            this.Controls.Add(this.panel1);
            this.Name = "UpdateDeliveryStatus";
            this.Text = "UpdateDeliveryStatus";
            this.Load += new System.EventHandler(this.UpdateInstallStatus_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label_DeliveryStatus;
        private System.Windows.Forms.ComboBox comboBox_DeliveryStatus;
        private System.Windows.Forms.Label label_DeliveryID;
        private System.Windows.Forms.TextBox textBox_DeliveryID;
        private System.Windows.Forms.Button button_cacel;
        private System.Windows.Forms.Button button_Update;
    }
}