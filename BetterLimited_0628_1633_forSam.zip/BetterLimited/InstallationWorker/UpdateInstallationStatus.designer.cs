﻿namespace BetterLimited
{
    partial class UpdateInstallationStatus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_cacel = new System.Windows.Forms.Button();
            this.button_Update = new System.Windows.Forms.Button();
            this.label_InstallationID = new System.Windows.Forms.Label();
            this.textBox_InstallationID = new System.Windows.Forms.TextBox();
            this.label_InstallationStatus = new System.Windows.Forms.Label();
            this.comboBox_InstallationStatus = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_cacel
            // 
            this.button_cacel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button_cacel.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_cacel.Location = new System.Drawing.Point(44, 193);
            this.button_cacel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_cacel.Name = "button_cacel";
            this.button_cacel.Size = new System.Drawing.Size(185, 38);
            this.button_cacel.TabIndex = 66;
            this.button_cacel.Text = "cancel";
            this.button_cacel.UseVisualStyleBackColor = false;
            this.button_cacel.Click += new System.EventHandler(this.button_cacel_Click);
            // 
            // button_Update
            // 
            this.button_Update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button_Update.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Update.Location = new System.Drawing.Point(252, 193);
            this.button_Update.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Update.Name = "button_Update";
            this.button_Update.Size = new System.Drawing.Size(185, 38);
            this.button_Update.TabIndex = 65;
            this.button_Update.Text = "Update";
            this.button_Update.UseVisualStyleBackColor = false;
            this.button_Update.Click += new System.EventHandler(this.button_Update_Click);
            // 
            // label_InstallationID
            // 
            this.label_InstallationID.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_InstallationID.Location = new System.Drawing.Point(68, 99);
            this.label_InstallationID.Name = "label_InstallationID";
            this.label_InstallationID.Size = new System.Drawing.Size(161, 25);
            this.label_InstallationID.TabIndex = 64;
            this.label_InstallationID.Text = "InstallationID :";
            // 
            // textBox_InstallationID
            // 
            this.textBox_InstallationID.Enabled = false;
            this.textBox_InstallationID.Location = new System.Drawing.Point(252, 99);
            this.textBox_InstallationID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_InstallationID.Name = "textBox_InstallationID";
            this.textBox_InstallationID.Size = new System.Drawing.Size(185, 25);
            this.textBox_InstallationID.TabIndex = 63;
            // 
            // label_InstallationStatus
            // 
            this.label_InstallationStatus.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_InstallationStatus.Location = new System.Drawing.Point(30, 144);
            this.label_InstallationStatus.Name = "label_InstallationStatus";
            this.label_InstallationStatus.Size = new System.Drawing.Size(185, 25);
            this.label_InstallationStatus.TabIndex = 62;
            this.label_InstallationStatus.Text = "Installation Status :";
            // 
            // comboBox_InstallationStatus
            // 
            this.comboBox_InstallationStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_InstallationStatus.FormattingEnabled = true;
            this.comboBox_InstallationStatus.Items.AddRange(new object[] {
            "pending",
            "installed"});
            this.comboBox_InstallationStatus.Location = new System.Drawing.Point(252, 147);
            this.comboBox_InstallationStatus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox_InstallationStatus.Name = "comboBox_InstallationStatus";
            this.comboBox_InstallationStatus.Size = new System.Drawing.Size(185, 23);
            this.comboBox_InstallationStatus.TabIndex = 61;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(26, 19);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(424, 43);
            this.label2.TabIndex = 23;
            this.label2.Text = "Update Installation Status";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(500, 73);
            this.panel1.TabIndex = 60;
            // 
            // UpdateInstallationStatus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 294);
            this.Controls.Add(this.button_cacel);
            this.Controls.Add(this.button_Update);
            this.Controls.Add(this.label_InstallationID);
            this.Controls.Add(this.textBox_InstallationID);
            this.Controls.Add(this.label_InstallationStatus);
            this.Controls.Add(this.comboBox_InstallationStatus);
            this.Controls.Add(this.panel1);
            this.Name = "UpdateInstallationStatus";
            this.Text = "UpdateInstallationStatus";
            this.Load += new System.EventHandler(this.UpdateInstallationStatus_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_cacel;
        private System.Windows.Forms.Button button_Update;
        private System.Windows.Forms.Label label_InstallationID;
        private System.Windows.Forms.TextBox textBox_InstallationID;
        private System.Windows.Forms.Label label_InstallationStatus;
        private System.Windows.Forms.ComboBox comboBox_InstallationStatus;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
    }
}