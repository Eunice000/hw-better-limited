﻿namespace BetterLimited
{
    partial class UpdateUserAccountForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateUserAccountForm));
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_Email = new System.Windows.Forms.Label();
            this.label_StaffID = new System.Windows.Forms.Label();
            this.label_UserName = new System.Windows.Forms.Label();
            this.label_UserAccountID = new System.Windows.Forms.Label();
            this.textBox_UserAccountID = new System.Windows.Forms.TextBox();
            this.textBox_Email = new System.Windows.Forms.TextBox();
            this.textbox_StaffID = new System.Windows.Forms.TextBox();
            this.textBox_UserName = new System.Windows.Forms.TextBox();
            this.button_cacel = new System.Windows.Forms.Button();
            this.button_Update = new System.Windows.Forms.Button();
            this.comboBox_Depart = new System.Windows.Forms.ComboBox();
            this.comboBox_Position = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Name = "label2";
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Name = "panel1";
            // 
            // label_Email
            // 
            resources.ApplyResources(this.label_Email, "label_Email");
            this.label_Email.Name = "label_Email";
            // 
            // label_StaffID
            // 
            resources.ApplyResources(this.label_StaffID, "label_StaffID");
            this.label_StaffID.Name = "label_StaffID";
            // 
            // label_UserName
            // 
            resources.ApplyResources(this.label_UserName, "label_UserName");
            this.label_UserName.Name = "label_UserName";
            // 
            // label_UserAccountID
            // 
            resources.ApplyResources(this.label_UserAccountID, "label_UserAccountID");
            this.label_UserAccountID.Name = "label_UserAccountID";
            // 
            // textBox_UserAccountID
            // 
            resources.ApplyResources(this.textBox_UserAccountID, "textBox_UserAccountID");
            this.textBox_UserAccountID.Name = "textBox_UserAccountID";
            this.textBox_UserAccountID.ReadOnly = true;
            // 
            // textBox_Email
            // 
            resources.ApplyResources(this.textBox_Email, "textBox_Email");
            this.textBox_Email.Name = "textBox_Email";
            // 
            // textbox_StaffID
            // 
            resources.ApplyResources(this.textbox_StaffID, "textbox_StaffID");
            this.textbox_StaffID.Name = "textbox_StaffID";
            this.textbox_StaffID.ReadOnly = true;
            // 
            // textBox_UserName
            // 
            resources.ApplyResources(this.textBox_UserName, "textBox_UserName");
            this.textBox_UserName.Name = "textBox_UserName";
            // 
            // button_cacel
            // 
            resources.ApplyResources(this.button_cacel, "button_cacel");
            this.button_cacel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button_cacel.Name = "button_cacel";
            this.button_cacel.UseVisualStyleBackColor = false;
            this.button_cacel.Click += new System.EventHandler(this.button_cacel_Click);
            // 
            // button_Update
            // 
            resources.ApplyResources(this.button_Update, "button_Update");
            this.button_Update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button_Update.Name = "button_Update";
            this.button_Update.UseVisualStyleBackColor = false;
            this.button_Update.Click += new System.EventHandler(this.button_Update_Click);
            // 
            // comboBox_Depart
            // 
            resources.ApplyResources(this.comboBox_Depart, "comboBox_Depart");
            this.comboBox_Depart.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Depart.FormattingEnabled = true;
            this.comboBox_Depart.Items.AddRange(new object[] {
            resources.GetString("comboBox_Depart.Items"),
            resources.GetString("comboBox_Depart.Items1"),
            resources.GetString("comboBox_Depart.Items2"),
            resources.GetString("comboBox_Depart.Items3"),
            resources.GetString("comboBox_Depart.Items4"),
            resources.GetString("comboBox_Depart.Items5"),
            resources.GetString("comboBox_Depart.Items6")});
            this.comboBox_Depart.Name = "comboBox_Depart";
            // 
            // comboBox_Position
            // 
            resources.ApplyResources(this.comboBox_Position, "comboBox_Position");
            this.comboBox_Position.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Position.FormattingEnabled = true;
            this.comboBox_Position.Items.AddRange(new object[] {
            resources.GetString("comboBox_Position.Items"),
            resources.GetString("comboBox_Position.Items1"),
            resources.GetString("comboBox_Position.Items2"),
            resources.GetString("comboBox_Position.Items3"),
            resources.GetString("comboBox_Position.Items4"),
            resources.GetString("comboBox_Position.Items5"),
            resources.GetString("comboBox_Position.Items6"),
            resources.GetString("comboBox_Position.Items7"),
            resources.GetString("comboBox_Position.Items8"),
            resources.GetString("comboBox_Position.Items9"),
            resources.GetString("comboBox_Position.Items10"),
            resources.GetString("comboBox_Position.Items11")});
            this.comboBox_Position.Name = "comboBox_Position";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // UpdateUserAccountForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox_Position);
            this.Controls.Add(this.comboBox_Depart);
            this.Controls.Add(this.button_cacel);
            this.Controls.Add(this.button_Update);
            this.Controls.Add(this.label_Email);
            this.Controls.Add(this.label_StaffID);
            this.Controls.Add(this.label_UserName);
            this.Controls.Add(this.label_UserAccountID);
            this.Controls.Add(this.textBox_UserAccountID);
            this.Controls.Add(this.textBox_Email);
            this.Controls.Add(this.textbox_StaffID);
            this.Controls.Add(this.textBox_UserName);
            this.Controls.Add(this.panel1);
            this.Name = "UpdateUserAccountForm";
            this.Load += new System.EventHandler(this.UpdateUserAccountForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label_Email;
        private System.Windows.Forms.Label label_StaffID;
        private System.Windows.Forms.Label label_UserName;
        private System.Windows.Forms.Label label_UserAccountID;
        private System.Windows.Forms.TextBox textBox_UserAccountID;
        private System.Windows.Forms.TextBox textBox_Email;
        private System.Windows.Forms.TextBox textbox_StaffID;
        private System.Windows.Forms.TextBox textBox_UserName;
        private System.Windows.Forms.Button button_cacel;
        private System.Windows.Forms.Button button_Update;
        private System.Windows.Forms.ComboBox comboBox_Depart;
        private System.Windows.Forms.ComboBox comboBox_Position;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
    }
}