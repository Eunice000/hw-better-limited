﻿
namespace BetterLimited
{
    partial class ForgotPasswordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ForgotPasswordForm));
            this.label1 = new System.Windows.Forms.Label();
            this.lblNewPasswordWarning = new System.Windows.Forms.Label();
            this.lblCPasswordWarning = new System.Windows.Forms.Label();
            this.txtConfirmPassword = new System.Windows.Forms.TextBox();
            this.txtNewPassword = new System.Windows.Forms.TextBox();
            this.lblConfirmPassword = new System.Windows.Forms.Label();
            this.lblNewPassword = new System.Windows.Forms.Label();
            this.lblUsernameWarning = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.lblUsername = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblForgotUsername = new System.Windows.Forms.Label();
            this.btnGetVerify = new System.Windows.Forms.Button();
            this.txtVerifyCode = new System.Windows.Forms.TextBox();
            this.lblVerify = new System.Windows.Forms.Label();
            this.picShowCPassword = new System.Windows.Forms.PictureBox();
            this.picShowNewPassword = new System.Windows.Forms.PictureBox();
            this.picIcon = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picShowCPassword)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picShowNewPassword)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picIcon)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Name = "label1";
            // 
            // lblNewPasswordWarning
            // 
            resources.ApplyResources(this.lblNewPasswordWarning, "lblNewPasswordWarning");
            this.lblNewPasswordWarning.ForeColor = System.Drawing.Color.Red;
            this.lblNewPasswordWarning.Name = "lblNewPasswordWarning";
            // 
            // lblCPasswordWarning
            // 
            resources.ApplyResources(this.lblCPasswordWarning, "lblCPasswordWarning");
            this.lblCPasswordWarning.ForeColor = System.Drawing.Color.Red;
            this.lblCPasswordWarning.Name = "lblCPasswordWarning";
            // 
            // txtConfirmPassword
            // 
            resources.ApplyResources(this.txtConfirmPassword, "txtConfirmPassword");
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.TextChanged += new System.EventHandler(this.txtConfirmPassword_TextChanged);
            // 
            // txtNewPassword
            // 
            resources.ApplyResources(this.txtNewPassword, "txtNewPassword");
            this.txtNewPassword.Name = "txtNewPassword";
            this.txtNewPassword.TextChanged += new System.EventHandler(this.txtNewPassword_TextChanged);
            // 
            // lblConfirmPassword
            // 
            resources.ApplyResources(this.lblConfirmPassword, "lblConfirmPassword");
            this.lblConfirmPassword.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblConfirmPassword.Name = "lblConfirmPassword";
            // 
            // lblNewPassword
            // 
            resources.ApplyResources(this.lblNewPassword, "lblNewPassword");
            this.lblNewPassword.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblNewPassword.Name = "lblNewPassword";
            // 
            // lblUsernameWarning
            // 
            resources.ApplyResources(this.lblUsernameWarning, "lblUsernameWarning");
            this.lblUsernameWarning.ForeColor = System.Drawing.Color.Red;
            this.lblUsernameWarning.Name = "lblUsernameWarning";
            // 
            // txtUsername
            // 
            resources.ApplyResources(this.txtUsername, "txtUsername");
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.TextChanged += new System.EventHandler(this.txtUsername_TextChanged);
            // 
            // lblUsername
            // 
            resources.ApplyResources(this.lblUsername, "lblUsername");
            this.lblUsername.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblUsername.Name = "lblUsername";
            // 
            // btnBack
            // 
            resources.ApplyResources(this.btnBack, "btnBack");
            this.btnBack.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnBack.Name = "btnBack";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnReset
            // 
            resources.ApplyResources(this.btnReset, "btnReset");
            this.btnReset.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnReset.Name = "btnReset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnClear
            // 
            resources.ApplyResources(this.btnClear, "btnClear");
            this.btnClear.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnClear.Name = "btnClear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblForgotUsername
            // 
            resources.ApplyResources(this.lblForgotUsername, "lblForgotUsername");
            this.lblForgotUsername.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblForgotUsername.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblForgotUsername.Name = "lblForgotUsername";
            this.lblForgotUsername.Click += new System.EventHandler(this.lblForgotUsername_Click);
            // 
            // btnGetVerify
            // 
            resources.ApplyResources(this.btnGetVerify, "btnGetVerify");
            this.btnGetVerify.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnGetVerify.Name = "btnGetVerify";
            this.btnGetVerify.UseVisualStyleBackColor = true;
            this.btnGetVerify.Click += new System.EventHandler(this.btnGetVerify_Click);
            // 
            // txtVerifyCode
            // 
            resources.ApplyResources(this.txtVerifyCode, "txtVerifyCode");
            this.txtVerifyCode.Name = "txtVerifyCode";
            // 
            // lblVerify
            // 
            resources.ApplyResources(this.lblVerify, "lblVerify");
            this.lblVerify.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblVerify.Name = "lblVerify";
            // 
            // picShowCPassword
            // 
            resources.ApplyResources(this.picShowCPassword, "picShowCPassword");
            this.picShowCPassword.Image = global::BetterLimited.Properties.Resources.show;
            this.picShowCPassword.Name = "picShowCPassword";
            this.picShowCPassword.TabStop = false;
            this.picShowCPassword.Click += new System.EventHandler(this.picShowCPassword_Click);
            // 
            // picShowNewPassword
            // 
            resources.ApplyResources(this.picShowNewPassword, "picShowNewPassword");
            this.picShowNewPassword.Image = global::BetterLimited.Properties.Resources.show;
            this.picShowNewPassword.Name = "picShowNewPassword";
            this.picShowNewPassword.TabStop = false;
            this.picShowNewPassword.Click += new System.EventHandler(this.picShowNewPassword_Click);
            // 
            // picIcon
            // 
            resources.ApplyResources(this.picIcon, "picIcon");
            this.picIcon.Image = global::BetterLimited.Properties.Resources.icon;
            this.picIcon.Name = "picIcon";
            this.picIcon.TabStop = false;
            // 
            // ForgotPasswordForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.txtVerifyCode);
            this.Controls.Add(this.lblVerify);
            this.Controls.Add(this.btnGetVerify);
            this.Controls.Add(this.lblForgotUsername);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.lblUsernameWarning);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.picShowCPassword);
            this.Controls.Add(this.picShowNewPassword);
            this.Controls.Add(this.lblNewPasswordWarning);
            this.Controls.Add(this.lblCPasswordWarning);
            this.Controls.Add(this.txtConfirmPassword);
            this.Controls.Add(this.txtNewPassword);
            this.Controls.Add(this.lblConfirmPassword);
            this.Controls.Add(this.lblNewPassword);
            this.Controls.Add(this.picIcon);
            this.Controls.Add(this.label1);
            this.Name = "ForgotPasswordForm";
            this.Load += new System.EventHandler(this.ForgotPasswordForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picShowCPassword)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picShowNewPassword)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picIcon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picIcon;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox picShowCPassword;
        private System.Windows.Forms.PictureBox picShowNewPassword;
        private System.Windows.Forms.Label lblNewPasswordWarning;
        private System.Windows.Forms.Label lblCPasswordWarning;
        private System.Windows.Forms.TextBox txtConfirmPassword;
        private System.Windows.Forms.TextBox txtNewPassword;
        private System.Windows.Forms.Label lblConfirmPassword;
        private System.Windows.Forms.Label lblNewPassword;
        private System.Windows.Forms.Label lblUsernameWarning;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblForgotUsername;
        private System.Windows.Forms.Button btnGetVerify;
        private System.Windows.Forms.TextBox txtVerifyCode;
        private System.Windows.Forms.Label lblVerify;
    }
}