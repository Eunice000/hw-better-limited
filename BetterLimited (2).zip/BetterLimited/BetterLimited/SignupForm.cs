﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BetterLimited
{
    public partial class SignupForm : Form
    {   
        Bitmap picShow = Properties.Resources.show;
        Bitmap picHide = Properties.Resources.hide;

        public SignupForm()
        {
            InitializeComponent();
            txtPassword.PasswordChar = '*';
            txtConfirmPassword.PasswordChar = '*';
            txtStaffID.MaxLength = 5;
            txtStaffID.KeyPress += new KeyPressEventHandler(txtStaffID_KeyPress);
            lblStaffIDWarning.Text = "";
            lblUsernameWarning.Text = "";
            lblPasswordWarning.Text = "";
            lblCPasswordWarning.Text = "";
            lblEmailWarning.Text = "";
            
        }
        private void txtStaffID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == Convert.ToChar(8)) //represents a backspace
            {
                e.Handled = false; //Accept the input
                lblStaffIDWarning.Text = "";
            }
            else
            {
                e.Handled = true; //Reject the input
                if (txtStaffID.TextLength != 5) {
                    lblStaffIDWarning.Text = "Staff ID should be numeric";
                }
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            LoginForm loginfrm = new LoginForm();
            this.Hide();
            loginfrm.Show();
        }

        private void txtUsername_Validating(object sender, CancelEventArgs e)
        {
            string errorMsg;
            if (!ValidUsername(txtUsername.Text, out errorMsg))
            {
                // Cancel the event and select the text to be corrected by the user.
                //e.Cancel = true;
                //txtUsername.Select(0, txtUsername.Text.Length);

                // Set the ErrorProvider error with the text to display. 
                //this.errorProvider1.SetError(textBox1, errorMsg);
                lblUsernameWarning.Text = errorMsg;
            }
            else {
                lblUsernameWarning.Text = "";
            }
        }

        public bool ValidUsername(string username, out string errorMessage)
        {
            // Confirm that the email address string is not empty.
            if (username.Length == 0)
            {
                errorMessage = "username is required.";
                return false;
            }

            // Confirm that there is an "@" and a "." in the email address, and in the correct order.
            if (username.Length >= 4 && username.Length <= 20)
            {
                errorMessage = "";
                return true;
            }else
            {
                errorMessage = "Usernames must be between 4 and 20 characters.";
                return false;
            }
        }

        private void txtConfirmPassword_Validating(object sender, CancelEventArgs e)
        {
            string errorMsg;
            if (!ConfirmPassword(txtConfirmPassword.Text, out errorMsg))
            {
                // Cancel the event and select the text to be corrected by the user.
                //e.Cancel = true;
                //txtUsername.Select(0, txtUsername.Text.Length);

                // Set the ErrorProvider error with the text to display. 
                //this.errorProvider1.SetError(textBox1, errorMsg);
                lblCPasswordWarning.Text = errorMsg;
            }
            else
            {
                lblCPasswordWarning.Text = "";
            }
        }

        public bool ConfirmPassword(string cpassword, out string errorMessage)
        {
            // Confirm that the email address string is not empty.
            if (cpassword.Length == 0)
            {
                errorMessage = "Confirm password is required.";
                return false;
            }

            // Confirm that there is an "@" and a "." in the email address, and in the correct order.
            if (cpassword == txtPassword.Text)
            {
                errorMessage = "";
                return true;
            }
            else
            {
                errorMessage = "Passwords do not match. Please try again";
                return false;
            }
        }

        private void txtStaffID_Validating(object sender, CancelEventArgs e)
        {
            string errorMsg;
            if (!ValidStaffID(txtStaffID.Text, out errorMsg))
            {
                // Cancel the event and select the text to be corrected by the user.
                //e.Cancel = true;
                //txtUsername.Select(0, txtUsername.Text.Length);

                // Set the ErrorProvider error with the text to display. 
                //this.errorProvider1.SetError(textBox1, errorMsg);
                lblStaffIDWarning.Text = errorMsg;
            }
            else
            {
                lblStaffIDWarning.Text = "";
            }
        }
        public bool ValidStaffID(string staffid, out string errorMessage)
        {
            // Confirm that the email address string is not empty.
            if (staffid.Length == 0)
            {
                errorMessage = "Staff ID is required.";
                return false;
            }
            if (staffid.Length == 5)
            {
                errorMessage = "";
                return true;
            }
            else
            {
                errorMessage = "Staff ID must be 5 digit.";
                return false;
            }
        }

        private void txtPassword_Validating(object sender, CancelEventArgs e)
        {
            string errorMsg;
            if (!ValidPassword(txtPassword.Text, out errorMsg))
            {
                // Cancel the event and select the text to be corrected by the user.
                //e.Cancel = true;
                //txtUsername.Select(0, txtUsername.Text.Length);

                // Set the ErrorProvider error with the text to display. 
                //this.errorProvider1.SetError(textBox1, errorMsg);
                lblPasswordWarning.Text = errorMsg;
            }
            else
            {
                lblPasswordWarning.Text = "";
            }
        }
        public bool ValidPassword(string password, out string errorMessage)
        {
            // Confirm that the email address string is not empty.
            if (password.Length == 0)
            {
                errorMessage = "Password is required.";
                return false;
            }
            if (password.Length >= 8)
            {
                errorMessage = "";
                return true;
            }
            else
            {
                errorMessage = "Password must be at least 8 characters long.";
                return false;
            }
        }

        private void txtEmail_Validating(object sender, CancelEventArgs e)
        {
            string errorMsg;
            if (!ValidEmail(txtEmail.Text, out errorMsg))
            {
                // Set the ErrorProvider error with the text to display. 
                lblEmailWarning.Text = errorMsg;
            }
            else
            {
                lblEmailWarning.Text = "";
            }
        }
        public bool ValidEmail(string email, out string errorMessage)
        {
            // Confirm that the email address string is not empty.
            if (email.Length == 0)
            {
                errorMessage = "Email address is required.";
                return false;
            }

            // Confirm that there is an "@" and a "." in the email address, and in the correct order.
            if (email.IndexOf("@") > -1)
            {
                if (email.IndexOf(".", email.IndexOf("@")) > email.IndexOf("@"))
                {
                    if (email.IndexOf("@") != 0 && email.IndexOf(".") != email.Length - 1) 
                    {
                        errorMessage = "";
                        return true;
                    }
                }
            }
            errorMessage = "Please enter a valid email address.\n" +
               "For example abc@def.com";
            return false;
        }

        private void picShowPassword_Click(object sender, EventArgs e)
        {
            if (picShowPassword.Image == picHide)
            {
                picShowPassword.Image = picShow;
            }
            else
            {
                picShowPassword.Image = picHide;
            }
            txtPassword.PasswordChar = picShowPassword.Image == picHide ? '\0' : '*';

        }

        private void picShowCPassword_Click(object sender, EventArgs e)
        {
            if (picShowCPassword.Image == picHide)
            {
                picShowCPassword.Image = picShow;
            }
            else
            {
                picShowCPassword.Image = picHide;
            }
            txtConfirmPassword.PasswordChar = picShowCPassword.Image == picHide ? '\0' : '*';
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtStaffID.Text = "";
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtConfirmPassword.Text = "";
            txtEmail.Text = "";

            lblStaffIDWarning.Text = "";
            lblUsernameWarning.Text = "";
            lblPasswordWarning.Text = "";
            lblCPasswordWarning.Text = "";
            lblEmailWarning.Text = "";
        }

        private void SignupForm_Load(object sender, EventArgs e)
        {
            this.ActiveControl = btnSignup;
        }
    }
}
