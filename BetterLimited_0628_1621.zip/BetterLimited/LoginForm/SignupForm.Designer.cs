﻿
namespace BetterLimited
{
    partial class SignupForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignupForm));
            this.label1 = new System.Windows.Forms.Label();
            this.lblStaffID = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblConfirmPassword = new System.Windows.Forms.Label();
            this.picIcon = new System.Windows.Forms.PictureBox();
            this.txtStaffID = new System.Windows.Forms.TextBox();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtConfirmPassword = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSignup = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblEmailWarning = new System.Windows.Forms.Label();
            this.lblCPasswordWarning = new System.Windows.Forms.Label();
            this.lblPasswordWarning = new System.Windows.Forms.Label();
            this.lblUsernameWarning = new System.Windows.Forms.Label();
            this.lblStaffIDWarning = new System.Windows.Forms.Label();
            this.picShowPassword = new System.Windows.Forms.PictureBox();
            this.picShowCPassword = new System.Windows.Forms.PictureBox();
            this.lblLowercase = new System.Windows.Forms.Label();
            this.lblNumber = new System.Windows.Forms.Label();
            this.lblUppercase = new System.Windows.Forms.Label();
            this.lblSymbols = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picShowPassword)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picShowCPassword)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Name = "label1";
            // 
            // lblStaffID
            // 
            resources.ApplyResources(this.lblStaffID, "lblStaffID");
            this.lblStaffID.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblStaffID.Name = "lblStaffID";
            // 
            // lblUsername
            // 
            resources.ApplyResources(this.lblUsername, "lblUsername");
            this.lblUsername.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblUsername.Name = "lblUsername";
            // 
            // lblPassword
            // 
            resources.ApplyResources(this.lblPassword, "lblPassword");
            this.lblPassword.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblPassword.Name = "lblPassword";
            // 
            // lblConfirmPassword
            // 
            resources.ApplyResources(this.lblConfirmPassword, "lblConfirmPassword");
            this.lblConfirmPassword.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblConfirmPassword.Name = "lblConfirmPassword";
            // 
            // picIcon
            // 
            resources.ApplyResources(this.picIcon, "picIcon");
            this.picIcon.Image = global::BetterLimited.Properties.Resources.icon;
            this.picIcon.Name = "picIcon";
            this.picIcon.TabStop = false;
            // 
            // txtStaffID
            // 
            resources.ApplyResources(this.txtStaffID, "txtStaffID");
            this.txtStaffID.Name = "txtStaffID";
            this.txtStaffID.Validating += new System.ComponentModel.CancelEventHandler(this.txtStaffID_Validating);
            // 
            // txtUsername
            // 
            resources.ApplyResources(this.txtUsername, "txtUsername");
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Validating += new System.ComponentModel.CancelEventHandler(this.txtUsername_Validating);
            // 
            // txtPassword
            // 
            resources.ApplyResources(this.txtPassword, "txtPassword");
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.TextChanged += new System.EventHandler(this.txtPassword_TextChanged);
            this.txtPassword.Validating += new System.ComponentModel.CancelEventHandler(this.txtPassword_Validating);
            // 
            // txtConfirmPassword
            // 
            resources.ApplyResources(this.txtConfirmPassword, "txtConfirmPassword");
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.TextChanged += new System.EventHandler(this.txtConfirmPassword_TextChanged);
            this.txtConfirmPassword.Validating += new System.ComponentModel.CancelEventHandler(this.txtConfirmPassword_Validating);
            // 
            // txtEmail
            // 
            resources.ApplyResources(this.txtEmail, "txtEmail");
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Validating += new System.ComponentModel.CancelEventHandler(this.txtEmail_Validating);
            // 
            // lblEmail
            // 
            resources.ApplyResources(this.lblEmail, "lblEmail");
            this.lblEmail.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblEmail.Name = "lblEmail";
            // 
            // btnClear
            // 
            resources.ApplyResources(this.btnClear, "btnClear");
            this.btnClear.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnClear.Name = "btnClear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSignup
            // 
            resources.ApplyResources(this.btnSignup, "btnSignup");
            this.btnSignup.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnSignup.Name = "btnSignup";
            this.btnSignup.UseVisualStyleBackColor = true;
            this.btnSignup.Click += new System.EventHandler(this.btnSignup_Click);
            // 
            // btnBack
            // 
            resources.ApplyResources(this.btnBack, "btnBack");
            this.btnBack.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnBack.Name = "btnBack";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblEmailWarning
            // 
            resources.ApplyResources(this.lblEmailWarning, "lblEmailWarning");
            this.lblEmailWarning.ForeColor = System.Drawing.Color.Red;
            this.lblEmailWarning.Name = "lblEmailWarning";
            // 
            // lblCPasswordWarning
            // 
            resources.ApplyResources(this.lblCPasswordWarning, "lblCPasswordWarning");
            this.lblCPasswordWarning.ForeColor = System.Drawing.Color.Red;
            this.lblCPasswordWarning.Name = "lblCPasswordWarning";
            // 
            // lblPasswordWarning
            // 
            resources.ApplyResources(this.lblPasswordWarning, "lblPasswordWarning");
            this.lblPasswordWarning.ForeColor = System.Drawing.Color.Red;
            this.lblPasswordWarning.Name = "lblPasswordWarning";
            // 
            // lblUsernameWarning
            // 
            resources.ApplyResources(this.lblUsernameWarning, "lblUsernameWarning");
            this.lblUsernameWarning.ForeColor = System.Drawing.Color.Red;
            this.lblUsernameWarning.Name = "lblUsernameWarning";
            // 
            // lblStaffIDWarning
            // 
            resources.ApplyResources(this.lblStaffIDWarning, "lblStaffIDWarning");
            this.lblStaffIDWarning.ForeColor = System.Drawing.Color.Red;
            this.lblStaffIDWarning.Name = "lblStaffIDWarning";
            // 
            // picShowPassword
            // 
            resources.ApplyResources(this.picShowPassword, "picShowPassword");
            this.picShowPassword.Image = global::BetterLimited.Properties.Resources.show;
            this.picShowPassword.Name = "picShowPassword";
            this.picShowPassword.TabStop = false;
            this.picShowPassword.Click += new System.EventHandler(this.picShowPassword_Click);
            // 
            // picShowCPassword
            // 
            resources.ApplyResources(this.picShowCPassword, "picShowCPassword");
            this.picShowCPassword.Image = global::BetterLimited.Properties.Resources.show;
            this.picShowCPassword.Name = "picShowCPassword";
            this.picShowCPassword.TabStop = false;
            this.picShowCPassword.Click += new System.EventHandler(this.picShowCPassword_Click);
            // 
            // lblLowercase
            // 
            resources.ApplyResources(this.lblLowercase, "lblLowercase");
            this.lblLowercase.BackColor = System.Drawing.Color.LightGray;
            this.lblLowercase.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblLowercase.Name = "lblLowercase";
            // 
            // lblNumber
            // 
            resources.ApplyResources(this.lblNumber, "lblNumber");
            this.lblNumber.BackColor = System.Drawing.Color.LightGray;
            this.lblNumber.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblNumber.Name = "lblNumber";
            // 
            // lblUppercase
            // 
            resources.ApplyResources(this.lblUppercase, "lblUppercase");
            this.lblUppercase.BackColor = System.Drawing.Color.LightGray;
            this.lblUppercase.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblUppercase.Name = "lblUppercase";
            // 
            // lblSymbols
            // 
            resources.ApplyResources(this.lblSymbols, "lblSymbols");
            this.lblSymbols.BackColor = System.Drawing.Color.LightGray;
            this.lblSymbols.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblSymbols.Name = "lblSymbols";
            // 
            // SignupForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.lblSymbols);
            this.Controls.Add(this.lblUppercase);
            this.Controls.Add(this.lblNumber);
            this.Controls.Add(this.lblLowercase);
            this.Controls.Add(this.picShowCPassword);
            this.Controls.Add(this.picShowPassword);
            this.Controls.Add(this.lblStaffIDWarning);
            this.Controls.Add(this.lblUsernameWarning);
            this.Controls.Add(this.lblPasswordWarning);
            this.Controls.Add(this.lblCPasswordWarning);
            this.Controls.Add(this.lblEmailWarning);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnSignup);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtConfirmPassword);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.txtStaffID);
            this.Controls.Add(this.lblConfirmPassword);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.lblStaffID);
            this.Controls.Add(this.picIcon);
            this.Controls.Add(this.label1);
            this.Name = "SignupForm";
            this.Load += new System.EventHandler(this.SignupForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picShowPassword)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picShowCPassword)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picIcon;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblStaffID;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblConfirmPassword;
        private System.Windows.Forms.TextBox txtStaffID;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtConfirmPassword;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSignup;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblEmailWarning;
        private System.Windows.Forms.Label lblCPasswordWarning;
        private System.Windows.Forms.Label lblPasswordWarning;
        private System.Windows.Forms.Label lblUsernameWarning;
        private System.Windows.Forms.Label lblStaffIDWarning;
        private System.Windows.Forms.PictureBox picShowPassword;
        private System.Windows.Forms.PictureBox picShowCPassword;
        private System.Windows.Forms.Label lblLowercase;
        private System.Windows.Forms.Label lblNumber;
        private System.Windows.Forms.Label lblUppercase;
        private System.Windows.Forms.Label lblSymbols;
    }
}