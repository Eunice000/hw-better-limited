﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace BetterLimited
{
    public partial class LoginForm : Form
    {
        Boolean show;
        Bitmap picShow = Properties.Resources.show;
        Bitmap picHide = Properties.Resources.hide;

           
        string server = "localhost";
        string username = "root";
        string password = "";
        string database = "betterlimited";

        public LoginForm()
        {
            InitializeComponent();
            
        }        
        private void LoginForm_Load(object sender, EventArgs e)
        {
            this.ActiveControl = btnLogin;        
            txtUsername.Text = "Username";
            txtUsername.ForeColor = Color.Gray;
            txtPassword.Text = "Password";
            txtPassword.ForeColor = Color.Gray;
        }
        private void txtUsername_Enter(object sender, EventArgs e)
        {
            if (txtUsername.Text == "Username")
            {
                txtUsername.Text = "";
                txtUsername.ForeColor = Color.Black;
            }
        }
        private void txtUsername_Leave(object sender, EventArgs e)
        {
            if (txtUsername.Text == "")
            {
                txtUsername.Text = "Username";
                txtUsername.ForeColor = Color.Gray;
            }
        }
        private void txtPassword_Enter(object sender, EventArgs e)
        {
            if (txtPassword.Text == "Password" && !show)
            {
                txtPassword.Text = "";
                txtPassword.PasswordChar = '*';
                txtPassword.ForeColor = Color.Black;
            }
            else if (txtPassword.Text == "Password" && show)
            {
                txtPassword.Text = "";
                txtPassword.PasswordChar = '\0';
                txtPassword.ForeColor = Color.Black;
            }
            else if (txtPassword.Text == null && show)
            {
                txtPassword.Text = "";
                txtPassword.PasswordChar = '\0';
                txtPassword.ForeColor = Color.Black;
            }
        }
        private void txtPassword_Leave(object sender, EventArgs e)
        {
            if (txtPassword.Text == "") {
                txtPassword.Text = "Password";
                txtPassword.PasswordChar = '\0';
                txtPassword.ForeColor = Color.Gray;
            } 
        }
        
        private void lblSignup_Click(object sender, EventArgs e)
        {
            SignupForm singupform = new SignupForm();
            this.Hide();
            singupform.Show();
            
        }
        private void picShowPassword_Click(object sender, EventArgs e)
        {
            
            if (picShowPassword.Image == picHide)
            {
                show = false;
                picShowPassword.Image = picShow;
            }
            else
            {
                show = true;
                picShowPassword.Image = picHide;
            }

            if (txtPassword.Text != "Password" || txtPassword.Text == "")
            {
                txtPassword.PasswordChar = show ? '\0' : '*';
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            MySqlConnection connStr = new MySqlConnection("server=" + server + ";" + "user id =" + username + ";" + "password=" + password + ";" + "database=" + database);
            string sqlStr = "SELECT * FROM useraccount WHERE UserName = '" + txtUsername.Text.Trim() + "' AND Password = '" + txtPassword.Text.Trim() + "'";
            MySqlDataAdapter dataAdapter = new MySqlDataAdapter(sqlStr, connStr);
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            dataAdapter.Dispose();

            if (dt.Rows.Count == 1)
            {
                MenuForm menuform = new MenuForm();
                this.Hide();
                menuform.Show();
            }
            else {
                MessageBox.Show("Incorrect user name or password. "
                    + "Please try again.");
                txtUsername.Text = "Username";
                txtUsername.ForeColor = Color.Gray;
                txtPassword.Text = "Password";
                txtPassword.PasswordChar = '\0';
                txtPassword.ForeColor = Color.Gray;
            }
        }
    }
}